# Teknisk dokumentasjon

Har samlet sammen endel teknisk dokumentasjon her. Det er ikke all dokumentasjon som er like oppdatert, fasiten ligger i kode ![(smile)](https://bufdir.atlassian.net/wiki/s/-1837753547/6452/ed9338f6a1977ef915cd6811188fcb147a29deb2/_/images/icons/emoticons/smile.png)

\*\* OBS; Denne dokumentasjonen migreres fortløpende til mer nærliggende systemer for utviklerene, og det er tekniske ressurser som er tiltenkt publikum her.\*\*