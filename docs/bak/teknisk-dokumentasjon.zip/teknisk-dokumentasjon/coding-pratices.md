# Coding pratices

These are the good practices that bufdir employs on the [http://bufdir.no](http://bufdir.no) solution. These should be followed if at all possible, and only deviated from when absolutly necessary.

Additions and edits on these will go through the lead developers for vetting before being implemented to the team, but are always welcome!