# Naming & Comments

## Naming conventions

### Pascal case

Use pascal casing ("PascalCasing") when naming a `class`, `record`, or `struct`.

```
hurr di durr
```

```
// C#
public class DataService
{
}

public record PhysicalAddress(
    string Street,
    string City,
    string StateOrProvince,
    string ZipCode);

public struct ValueCoordinate
{
}

```

When naming an `interface`, use pascal casing in addition to prefixing the name with an `I`. This clearly indicates to consumers that it's an `interface`.

```
public interface IWorkerQueue
{
}

```

When naming `public` members of types, such as fields, properties, events, methods, and local functions, use pascal casing.

```
public class ExampleEvents
{
    // A public field, these should be used sparingly
    public bool IsValid;

    // An init-only property
    public IWorkerQueue WorkerQueue { get; init; }

    // An event
    public event Action EventProcessing;

    // Method
    public void StartEventProcessing()
    {
        // Local function
        static int CountQueueItems() => WorkerQueue.Count;
        // ...
    }
}

```

When writing positional records, use pascal casing for parameters as they're the public properties of the record.

```
public record PhysicalAddress(
    string Street,
    string City,
    string StateOrProvince,
    string ZipCode);

```

For more information on positional records, see [Positional syntax for property definition](https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/record#positional-syntax-for-property-definition).

### Camel case

Use camel casing ("camelCasing") when naming `private` or `internal` fields, and prefix them with `_`.

```
public class DataService
{
    private IWorkerQueue \_workerQueue;
}

```

 Tip

When editing C# code that follows these naming conventions in an IDE that supports statement completion, typing `_` will show all of the object-scoped members.

When working with `static` fields that are `private` or `internal`, use the `s_` prefix and for thread static use `t_`.

```
public class DataService
{
    private static IWorkerQueue s\_workerQueue;

    \[ThreadStatic\]
    private static TimeSpan t\_timeSpan;
}

```

When writing method parameters, use camel casing.

```
public T SomeMethod<T>(int someNumber, bool isValid)
{
}
```

## Commenting conventions

*   Place the comment on a separate line, not at the end of a line of code.
    
*   Begin comment text with an uppercase letter.
    
*   End comment text with a period.
    
*   Insert one space between the comment delimiter (//) and the comment text, as shown in the following example.
    
    ```
    // The following declaration creates a query. It does not run
    // the query.
    
    ```
    
*   Don't create formatted blocks of asterisks around comments.
    
*   Ensure all public members have the necessary XML comments providing appropriate descriptions about their behavior.
    
*   Comment sparsely but when necessary, since comments rarely get maintained they often lead to misgivings about the behaviour of the code.