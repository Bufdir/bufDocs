# Tools and Technology

These are the standard tools that we use in the bufdir project. You are free to use other tools that you have at your disposal, as long as they do not impede yourself or others, or impose conditions on the project to work.

## Technologies

*   .net 4.8
    
*   .net 5.0
    
*   .net Core 3.0
    
*   Azure SQL server/database
    
*   Node 14
    
*   React 17
    
*   Sass (SCSS-syntax)
    
*   Webpack 4
    
*   Airbnb's ESLint config
    
*   [ReactJs.NET](http://ReactJs.NET)
    

## IDE

### Visual Studio

We advice you to use Visual Studio in order to run and debug the project due to its integration and capabilities with IIS. There are debug profiles in the project which can “simulate” the different enviroments that we have based on the config transforms.

### Visual Studio Code

We strongly advice to use vs code for writing frontend code with the option to format on save set to true and the default formatter set to prettier. This will ensure that your code is automatically formatted to follow our eslint setup. If this should turn out to be of any problem, please contact the projects front end tech lead and we’ll try to sort it out.