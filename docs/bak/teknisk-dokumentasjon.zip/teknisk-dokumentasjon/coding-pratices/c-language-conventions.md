# C# Language conventions

In general we follow microsofts best practices, and will refer to their updated documentation on the basics here: [https://docs.microsoft.com/en-us/dotnet/csharp/fundamentals/coding-style/coding-conventions#language-guidelines](https://docs.microsoft.com/en-us/dotnet/csharp/fundamentals/coding-style/coding-conventions#language-guidelines)

What follows are specialisations and customizations that bufdir has made or tweaks to the standard.