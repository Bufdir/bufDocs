# API - respons format og -håndtering

Dette dokumentet legger føring for bruk av HTTP status koder og JSON format på API responser, samt best practices for håntering av fetch-reponse i React.

# Målsetting

Konsumering av reponsen skal underbygge behovet i frontend for å enkelt kunne håndtere feil på et høyere/generellt nivå for å ungå:

*   gjentakende boilerplate kode dypt nede i komponentene som initisierer requesten
    
*   spesial-håndtering av enkelt-responser dersom backend ikke har en klar standard å forholde seg til
    
*   Differensiering av forskjellige responsformater med samme http status
    

# Ressurser

## Problemdetails

[https://datatracker.ietf.org/doc/html/rfc7807](https://datatracker.ietf.org/doc/html/rfc7807)

Likewise, truly generic problems -- i.e., conditions that could potentially apply to any resource on the Web -- are usually better expressed as plain status codes.

For example, a "write access disallowed" problem is probably unnecessary, since a 403 Forbidden status code in response to a PUT request is self-explanatory.

## JSON API

[https://jsonapi.org/](https://jsonapi.org/)

When a server encounters multiple problems for a single request, the most generally applicable HTTP error code SHOULD be used in the response. For instance, 400 Bad Request might be appropriate for multiple 4xx errors or 500 Internal Server Error might be appropriate for multiple 5xx errors.

## Fecth API

[https://developer.mozilla.org/en-US/docs/Web/API/Fetch\_API/Using\_Fetch](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch)

The Promise returned from fetch() won't reject on HTTP error status even if the response is an HTTP 404 or 500. Instead, as soon as the server responds with headers, the Promise will resolve normally (with the ok property of the response set to false if the response isn't in the range 200–299), and it will only reject on network failure or if anything prevented the request from completing.

## Http status codes

[https://en.wikipedia.org/wiki/List\_of\_HTTP\_status\_codes](https://en.wikipedia.org/wiki/List_of_HTTP_status_codes)

# Spesifikasjon

## Flytskjema

![](./attachments/image-20231110-082614.png)

## GUI Feedback levels

1.  System
    
    1.  Form
        
        1.  Felt
            

**System**

*   500
    
*   Response-parsing
    
*   Autentisering / autorisering (“Access denied”)
    

**Form**

*   Response-parsing
    
*   4xx
    

**Felt**

*   4xx med angitte felt i `errors`
    

# Response schema

Response objektet har følgende stuktur på topp-nivå (fra [JSON API](https://jsonapi.org/format/#document-top-level)):

*   **data**: the document’s “primary data”
    
*   **errors**: an array of error objects
    
*   **meta**: a meta object that contains non-standard meta-information.
    

***data*** og ***errors*** må ikke eksistere i samme dokument.

I tillegg supplementers feil med følgende properties fra ProblemDetails (alt etter hvordan backendkoden implementerer [ProblemDetails](https://datatracker.ietf.org/doc/html/rfc7807))

*   extensions
    
    *   Brukes ikke
        
*   instance
    
    *   Brukes ikke
        
*   status
    
    *   Ignoreres, http-status foretrekkes
        
*   **detail**
    
*   **title**
    
*   **type**
    

***type**, **title** og **detail*** er obligatorisk på error-responser.

## Meta: object

Http status: Alle

Meta kan feks brukes til å sende med ***informasjon i dev-miljø***, som:

*   Magiske lenker som i produksjon vil bli sent via epost
    
*   Schema-definisjon på data i responsen i responsen ved suksess
    
    *   Denne kan absolutt være med på å lette frontend utvikling, også TS typedefinisjoner og tester
        
        *   (Alternativ vil være noe ala Swagger for å sjekke dette)
            

Meta brukes også av frontend til å “patche opp” responsen med props som ikke kan komme fra backend, feks error ved parsing av respons-body til JSON. Se seksjon om frontend under.

## Data: array|object|null

Http status: 2xx - OK / OK-ish

Primær data. Grunnen til at primærdata ikke bør legges rett på rot-nivå er at samlede primærdata er kognitivt lettede for frontend, som med `root.data` får egen “container” å forholde seg til, som skiller primærdata klart fra `meta`\-props og problemDetails responser.

Merk! **204 No Content** og andre “non-json” ok-responser må taes høyde for i frontend for å parse resultatet riktig.

## Type: url

Http status: >= 300 - NOT OK

**Type** feltet fra **problemDetails** er en url-identifier, med eller uten korrespondende side serverside.

Feltet er defacto definisjonen på feilkoder og må være velkjent både backend og frontend.

Frontend bruker feltet til å enkelt differensierer feil uten å måtte grave i responser.

## Errors: object<key: string, value: string\[\]>

Http status: >= 400 - NOT OK

#### Problemstillinger / avklaringer

Frontend-validering er et must. Dersom backend gir en 4xx-feil, må dette være en “kjent” feil i frontend, fordi:

1.  **Invalid fields** fra backend er en BUG på den måten at det ikke er samme felt-validering BE og FE:
    
    1.  Feilen er kode-mismatch, og bør håndteres som en BUG, ikke en brukerfeil
        
        1.  Kan like så godt gi en generisk “Noe gikk feil”-melding i GUI som å prøve å markere feltet som feilet?
            
        2.  System-nivå eller form-nivå
            
2.  **Conflicting fields**
    
    1.  Dersom alle dataene som kan konfliktere ligger i frontend, så skal det kunne valideres i frontend. - Hvis ikke så er det en frontend BUG
        
    2.  Dersom en eller flere av feltene i error-reponsen er ukjent i frontend, så er det en form-nivå feil i GIU
        
        1.  Frontent må vite om feilen ved å kunne filtrere på **Type**
            
    3.  Noen tilfeller må spesial-behandles, som unike brukernavn, opptatte eposter etc
        
        1.  Det kan/bør være autocomplete / async oppslag fra feltet
            
3.  **Forbidden**. Autentisering / autorisering.
    

Dette vil (antagligvis og strengt tatt) si at for alle backend-feil så er **hvilke felter** irrelevant, og *kan* ansees som metatdata. Det som da blir viktig er **Status** og **Type**, fordi samme status kan gjelde flere typer feil. - Strengt tatt kunne vi klart oss med kun 400 og 500 feil, og spesifisert med type…

# Http-status code example responses (Utdatert!)

Merk! Eksemplene er ***ikke*** genuine responser, og innhar feil i forhold til spec'en! De bør oppdateres eller fjernes elns.

### 400 Bad Request

```
HTTP/1.1 400 Bad Request
Content-Type: application/problem+json
Content-Language: en

{
  "type": "https://example.net/validation-error",
  "title": "Your request parameters didn't validate.",
  "errors": \[{
      "name": "age",
      "reason": "must be a positive integer"
    },
    {
      "name": "color",
      "reason": "must be 'green', 'red' or 'blue'"
    }\]
}
```

#### Problemstillinger / avklarlinger

Flere typer feil kan generer responsen?

*   **Type**
    

### 403 Forbidden

```
HTTP/1.1 403 Forbidden
Content-Type: application/problem+json
Content-Language: en

{
  "type": "https://example.net/access-denied",
  "title": "Access denied",
  "detail": "User is not logged in",
}
```

#### Problemstillinger / avklarlinger

Flere typer feil kan generer responsen?

*   **Type**
    

#### Eksempler:

1.  Request mot en ressurs => 403
    
    1.  Incativity timeout => ikke logget inn?
        
    2.  Ressurs låst på grunn av prop states?
        
    3.  Bruker har ikke riktig tilgangsnivå?
        
    4.  Bruker er ikke i riktig gruppe => ansees som ikke logget inn på ressursen
        

### 404 Not Found

```
HTTP/1.1 404 Not found
Content-Type: application/problem+json
Content-Language: en

{
  "type": "https://example.net/empty-result",
  "title": "Not found"
  "detail": "No matching resource found",
}
```

```
HTTP/1.1 404 Not found
Content-Type: application/problem+json
Content-Language: en

{
  "type": "https://example.net/page-not-found",
  "title": "Not found",
  "detail": "Page not found",
}
```

#### Problemstillinger / avklarlinger

Flere typer feil kan generer responsen?

*   **Type**
    

#### Eksempler:

*   Ikke-eksisterende URLer
    
    *   Alle metoder: “Syntaks-feil” i hardkodede urler
        
    *   GET hvor searchString ikke resulterer i treff i DB
        
    *   Alle metoder: Variabel-interpolerte urler som ikke resulterer i treff i DB
        
*   POST etc hvor body ikke resulterer i treff i DB
    

### 409 Conflict

“Dypere oppslagsfeil” i backend på props frontend ikke har tilgang til

```
HTTP/1.1 409 Conflict
Content-Type: application/problem+json
Content-Language: en

{
  "type": "https://example.net/conflict",
  "title": "Conflict",
  "detail": "Cannot have your cake and eat it too",
}
```

```
HTTP/1.1 409 Conflict
Content-Type: application/problem+json
Content-Language: en

{
  "type": "http://localhost:3000/error-type/fields-conflict",
  "title": "Failed to update profile",
  "detail": "Conflicting values",
  "errors": \[
    {
      "name": "username",
      "reason": "Username is already taken by someone else"
    }
  \]
}
```

### 5xx Server Error

```
HTTP/1.1 5xx \[WHATEVER SERVER SENDS\]
Content-Type: application/problem+json
Content-Language: en

{
  "type": "https://example.net/server-error",
  "title": "Server error",
  "detail": "Something went wrong",
}
```

# Klientside håndtering

[Fetch API - RESPONSE](https://developer.mozilla.org/en-US/docs/Web/API/Response)

Properties

*   Response.body
    
    *   Response.bodyUsed
        
*   Response.ok
    
    *   Response.status
        
    *   Response.statusText
        
*   Response.url
    

Methods

*   Response.json()
    
    *   Returns a promise that resolves with the result of parsing the response body text as JSON
        
    *   Flags Response.bodyUsed = true
        

## Eksempel (Utdatert)

Som beskrevet Flytskjema swimlane `useApi (Custom hook)` ovenfor:

```
const NON\_JSON\_SUCCESS\_STATUSES = Object.freeze({
  // Statustext as key to get statuscode as int
  'NO CONTENT': 204,
});

const TYPE\_URL\_BASE = 'https://example.net/error-type/';

const HANDLED\_ERROR\_TYPES = \[
  '/unauthenticated/not-logged-in',
  '/unauthorized/not-consented',
\];

const shouldHandleErrorTypeHere = (errorType: string): boolean => {
  const isHandledLater =
    typeof errorType === 'string' &&
    !!HANDLED\_ERROR\_TYPES.find((typeSuffix) => {
      // debug('shouldHandleErrorTypeHere', { errorType, typeSuffix });
      return errorType.endsWith(typeSuffix);
    });
  return !isHandledLater;
};

const createApiCallWrapper = ({
  apiKey,
  apiCall,
  onPending,
  onComplete,
}: CreateApiCallWrapperArgs): WrappedApiCall => {
  const notifications = useNotifications();

  return async (...args: unknown\[\]) => {
    let abortController: AbortController | undefined = args.find(
      (arg: unknown): arg is AbortController => arg instanceof AbortController,
    );

    if (!abortController) {
      abortController = createAbortController();
      args.push(abortController);
    }

    debug(\`wrappedApiCall:${apiKey}\`, { apiKey, apiCall, abortController });

    let response: Response | undefined;
    let result: ApiResult = {};

    if (onPending instanceof Function) {
      onPending();
    }

    try {
      response = await apiCall(...args);
      result = Object.values(NON\_JSON\_SUCCESS\_STATUSES).includes(
        response.status,
      )
        ? {}
        : await response.json();
    } catch (err) {
      logError(err as Error);
      const meta: Record<string, unknown> = {
        catchBlockError: true,
      };
      if (abortController.signal.aborted) {
        // Assume useEffect cleanup if no \`signal.reason\`, and sets \`abortReson\` to "ABORTED"
        const abortReason = (
          abortController.signal.reason || 'ABORTED'
        ).toLowerCase();

        result = {
          meta,
          type: cleanUrl(\`${TYPE\_URL\_BASE}/request-${abortReason}\`),
          title: 'Request was cancelled',
          details: \`Request for (${apiKey}) was aborted by signal\`,
        };
      } else {
        result = {
          meta,
          type: cleanUrl(\`${TYPE\_URL\_BASE}/response-parsing-error\`),
          title: 'Client side parsing error',
          details: (err as Error).toString(),
        };
      }
    }

    if (!result.meta) {
      result.meta = {};
    }

    if (response) {
      Object.assign(result.meta, {
        url: response.url,
        success:
          !result.meta.catchBlockError &&
          response.status >= 200 &&
          response.status < 300,
      });
    }

    if (
      !result.meta.success &&
      ((result.meta.status as number) >= 500 ||
        (result as ApiErrorResult).type.endsWith('response-parsing-error'))
    ) {
      // Flag any server-error or type "response-parsing-error" as a runtime-exception
      result.meta.isRuntimeException = true;
    }

    debug(\`wrappedApiCall:${apiKey}\`, { result });

    if (onComplete instanceof Function) {
      onComplete(result);
    }

    if (!result.meta.success && shouldHandleErrorTypeHere(result.type)) {
      const textId = apiResultErrorType2TextId(result.type);

      notifications.addSystemError(
        t(\`System:ApiErrors.${textId}\`, {
          ...result.meta,
          interpolation: { escapeValue: false },
        }),
      );
    }

    return Object.freeze(result);
  };
};

```