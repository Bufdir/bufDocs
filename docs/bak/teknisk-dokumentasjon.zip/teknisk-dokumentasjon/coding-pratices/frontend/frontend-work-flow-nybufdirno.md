# Frontend Work Flow ny.bufdir.no

## Work Flow

This is the workflow for the repos named [Bufdir.no](http://Bufdir.no) and [http://ny.bufdir.no](http://ny.bufdir.no) . In other projects, that may not use [Reactjs.net](http://Reactjs.net) for SSR in the backend layer, other work flows apply.

### Creating a new component

We write components in react, while running them through a story in [Storybook](https://storybook.js.org/docs/react/get-started/introduction). This will give you a GUI layer with hot reload for your component that is independent from the full application to run.

To mount a component in storybook, create a file in the same folder as your component and name it <ComponentName>.stories.mdx. See how other mdx files are written to know how to make a story for your component and read the documentation for the [MDX format here](https://storybook.js.org/docs/react/api/mdx).

You can also use [buflib\_cli](https://www.npmjs.com/package/buflib_cli) in a bash terminal to scaffold components and stories from the ./src/site directory.

To run the Storybook environment run

```
npm run storybook
```

in your bash terminal from the ./src/site directory.

### Mounting a component into the .NET application

At the time of writing we do not run out frontend 100% decoupled from the backend in a headless way, but are using a hybrid solution by mounting our react components into the backend by using a .NET package called [ReactJS.NET](http://reactjs.net). The way this works is by using Reactjs.nets API to mount our component into a .NET view file called a “razor” file (file extention .cshtml) in a similar fashion to what we are used to when mounting one react component into another. But with one major drawback: **it does not support the children prop**. This means that you cannot pass components into other components in a razor file (but you can still pass components into components within react files as usual). On the upside [ReactJs.NET](http://ReactJs.NET) supports [SSR](https://developers.google.com/web/updates/2019/02/rendering-on-the-web#server-rendering).

First you need to expose your component to [Reactjs.NET](http://Reactjs.NET) by importing your component into the file src\\Site\\Scripts\\components\\index.js and adding it to the global.Components object in the same file.

Then compile the frontend either by running `npm run develop` to get source maps and hot reloading, or by building for production by running `npm run build`.

Then mount your component into a razor file.

Here is an example of a react component, called BdHero, mounted into a razor file:

`@Html.React("Components.BdHero", new{    title=Model.Heading,    ingress=Model.MainIntro,    linkText=Model.LinkText,    linkUrl=Url.ContentUrl(Model.Link),    imageUrl=Url.ContentUrl(Model.Image),    imageAltText=Model.ImageAltText,    isSecondary = !Model.UseSecondaryColor`

```
})
```

This example takes .NET variables prepared by the backend for the view and passes them to the components props.