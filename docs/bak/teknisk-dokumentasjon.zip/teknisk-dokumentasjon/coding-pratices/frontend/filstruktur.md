# Filstruktur

## Filstruktur

Dette er en anbefaling. Avvik kan gjøres etter kjønn.

### Mapper

*   .*/docs -* md filer med ytterligere dokumentasjon for prosjektet og rutiner for å jobbe i dette prosjektet.
    
*   *./build/ -* filer hvor poenget er å hjelpe til med å opprette ressurser i distmappa, eller hjelpe til med en hmr-prosess, men som ikke nødvendigvis er med til dist. Eksempel: dummy json api til hjelp under utvikling. Eksempel 2: index.html (hvis løsningen ikke er en SPA som bruker index.html-fila i prod).
    
*   *./assets/ -* statiske filer som hentes inn i kildekode. Eksempel: fonter, bilder, index.html (om løsningen ikke er en SPA).
    
    *   *./assets/fonts/ -* fontfiler.
        
    *   *./assets/images/ -* bildefiler.
        
*   *./dist/ -* kompilerte bundles og assets til konsum i sluttløsningen. Ingen manuell koding i denne mappa.
    
*   *./src/ -* kildekode og grunnlag for bundle beskrevet i punktet ./dist/
    
    *   *./src/main.js -* startpunkt for kildekode med registrering av app.
        
    *   *./src/pages/ -* Komponenter med egne routes.
        
    *   *./src/state/ -* All kode som har med global state management å gjøre.
        
        *   *./src/state/slices/ -* Global state managementkode seksjonert opp i logiske områder.
            
    *   *./src/locale/ -* All kode og ressurser som har med statiske språkstrenger å gjøre.
        
        *   *./src/locale/translations -* statiske json-filer med språkstrenger definert.
            
    *   *./src/components/ -* Gjenbrukbare react-komponenter med alle ressurser (stilkode, bilder etc) som kun brukes av denne komponenten.
        
    *   *./src/helpers/ -* Gjenbrukbare generiske javascript/typescript-funksjoner.
        
        *   *./src/helpers/services/ -* Gjenbrukbare generiske funksjoner som fyrer av ajax-requester.
            
    *   *./src/styles/ -* Global stilkode og stilhjelpere som konsumeres på tvers av komponentene.
        
        *   *./src/styles/index.scss -* inngangs for stilkode.
            
        *   *./src/styles/variables/ -* scss/css variables.
            
        *   *./src/styles/maps/ -* scss maps/arrays.
            
        *   *./src/styles/functions -* scss functions.
            
        *   *./src/styles/components -* css-komponenter som kan brukes på tvers av komponenter. Eksempel: .(prefix)-button
            
        *   *./src/styles/mixins/ -* scss mixins.
            

### Rotfiler

*   *./readme.md -* dokumentasjon av hva prosjektet er, hvordan å kjøre det opp, og pekere til ytterligere dokumentasjon.
    
*   *./changelog.md -* standardisert endringslogg med endringer pr release / deploy til prod.
    
*   *./.env -* environment variables ment for konsum i frontendbygget eller runtime med ajax i frontendkoden.
    
*   *./example-env -* eksempel på alle variabler som kan defineres med dummyverdier, om disse ikke alle kan leses i sin fullstendige form med faste verdier i .env-filen.
    
*   *./package.json*
    
*   *./package-lock.json*
    
*   *./.eslintignore*
    
*   *./.eslint.rc*
    
*   *./.gitignore*
    
*   *./.prettierrc.json*
    
*   *./tsconfig.json*