# Making Pull Requests

# Making good Pull Request

**TLDR; Have empathy for your code reviewers while developing and preparing for making pull requests.**

## PR Guidelines

**A PR should:**

*   be short and consice
    
*   be easy to understand
    
*   be consistent with the established flows in the system
    
*   not break anything
    

### Pull requests should be short and concise

In principle the PR should only be about what the title and the related task is about. If the title does not cover all the things done in the PR, the extra code should only be a few lines of code, and it should revolve around the theme of the title and the task.

If your PR have changes in more than 10 files, you should consider splitting into separate PRs.

### Pull requests should be easy to understand

Name things according to what they do. Long variable and function names never killed nobody. Make comments for functions and methods that explains what they do. Think about splitting code into separate files where logical if files get big.

Structure your code changes in a way that makes it easy for the code reviewer to read, and that is also good for the readability of the repo on the whole.

In principal the code reviewer should easily be able to know what the changes does, just by looking at the diff. If it is not easily understandable by looking at the diff - add descriptions (and screenshots of GUI if applicable) of what the code in the PR does.

Don't expect the code reviewer to run the code to understand what it does.

### Pull requests should be consistent with the established flows in the system

Do not deviate from the practises of the system, unless this is a refactor of one such flow.

### Pull requests should not break anything

Make sure your code changes does not break existing code, and that your changes does not break the system.

Run the solution, test your code well, run the automatic tests, and write new automatic tests, if applicable. Do this while developing, but also as the last step before creating the PR.

Don't expect the code reviewer to run the code to test that it works.