# Frontend

## Technologies

*   Node >= v14
    
*   React >= v17
    
*   Sass (SCSS-syntax)
    
*   Vite
    
*   Airbnb's ESLint config
    
*   ReactJs.NET
    

## IDE

### Visual Studio Code

We strongly advice to use vs code for writing frontend code with the option to format on save set to true and the default formatter set to prettier. This will ensure that your code is automatically formatted to follow our eslint setup. If this should turn out to be of any problem, please contact the projects front end tech lead and we’ll try to sort it out.

#### Settings

To enable the autoformatting options in vs code, press `ctrl+p` to get the command input and search for "settings", then pick the option to open the settings.json file and add to it:  

```
"editor.formatOnSave": true,
"editor.defaultFormatter": "esbenp.prettier-vscode",
```

Make sure to have the prettier plugin installed in your vs code instance.

#### Recommended Plugins

|     |     |
| --- | --- |
| **Navn** | **Beskrivelse** |
| EditorConfig for VS Code | Støtte for standardiserte workspace innstillinger definert i .editorconfig<br><br>Support for standardized workspace settings defined in .editorconfig |
| ESLint | Linting based on rules defined in .eslintrc |
| Prettier | Autoformattering of coding rules defined in .eslintrc and .prettierrc |
| GitLens | Git blame per line of code and much more |
| Import Cost | Shows package size on imports |
| React Extension Pack | Set of supporting plugins for writing React/JSX/Javascript |
| VSCode MDX | Linting and autoformattering for MDX-files used in Storybook stories |

## Conventions

### Naming

*   Name your component and its tsx and scss file with PascalCase
    
*   Name your components folder the same as your component but in snake\_case
    
*   Name all (frontend) folders in snake\_case
    
*   The root class of your components styling should be named the same as your component but in kebab-case
    

### Code Comments

Try to avoid spreading out alot of comments through your code, and instead make sure that your code is readable. There is no shame in long variable and function names - it gets uglified for production. In some cases we need to write code that is not instantly recognisable and in those cases we do include code comments on the line above the start of the respective code.

Other than that we do have two things we document as code comments, the component and its props. The main audience for these descriptions are backenders that can choose to mount components into a .NET view file, so avoid going into frontend specifics.

*   Write a short abstract description of what the component is and is for right over the component definition.
    
*   Write a short description for each prop in the type definition describing what does if used.
    

### Other

*   Put the component file in its own folder and have all assets (types, scss, images, docs etc) specific to that component in the same folder.
    
*   Use function components and hooks.
    
*   Use BEM for scss.
    
*   Use our react/css component library, called [buflib](https://stbuflibdev.z16.web.core.windows.net/), where it makes sence to ensure reuse across several of Bufdirs web projects (it is used also outside of the bufdir.no-sphere)
    

## Related

*   [https://bufdir.atlassian.net/wiki/spaces/DIGUTV/pages/707198980](https://bufdir.atlassian.net/wiki/spaces/DIGUTV/pages/707198980)
    
*   [Frontend Work Flow ny.bufdir.no](./frontend/frontend-work-flow-nybufdirno.md)
    
*   [Suggested Frontend File Structure (Norwegian)](./frontend/filstruktur.md)