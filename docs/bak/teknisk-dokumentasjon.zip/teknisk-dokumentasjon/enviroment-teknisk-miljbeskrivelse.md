# Enviroment (Teknisk Miljøbeskrivelse)

# New [http://bufdir.no](http://bufdir.no) enviroment

### Development

### Dev-Test

Dev-test enviroment is a full fledged enviroment ment for integration testing, early preview of functionality and developer testing of the solution.

The enviroment contains a full, down-scaled, enviroment similar in setup and layout to the production enviroment, and has CI/CD pipelines running on commits to the development branch.

It is hosted in “Fantomet” tenant for flexibility.

In order to access the resources, developer needs to be part of the “  
BufdirnoSecurityGroup” in azure AD.

|     |     |
| --- | --- |
| URL | [https://bufdirweb-test.azurewebsites.net](https://bufdirweb-test.azurewebsites.net) |
| SQL | [sql-bufdir-test.database.windows.net](http://sql-bufdir-test.database.windows.net) |
|     |     |

![](./attachments/image-20210909-073522.png)

### Staging

### Production

# Old [bufdir](http://bufdir.no) solution enviroment

[Bufdir.no](http://Bufdir.no) is buildt up using 3 full enviroments and 1 partial.

The partial enviroment is Development enviroment, which consists of full set of databases, a keyvault and storage account. The

The full enviroments consists of a set of databases under a sql server, a keyvault, storage account and a viritual machine running the solution. These are:

### Development

Development enviroment is the developers playground. It consists of a common set of databases, a keyvault, storage account and local installations of the solution on the developers machine.

|     |     |
| --- | --- |
| URL |     |
| SQL |     |
| Provider (AD) | Fantomet |

![](./attachments/image-20210422-120109.png)

### DevTest

The test enviroment, or devtest as it is labled, is a test enviroment based on the development branch. There is a CI/CD pipeline set up based on check inn to the development branch.

|     |     |
| --- | --- |
| URL | [http://bufepitest.norwayeast.cloudapp.azure.com](http://bufepitest.norwayeast.cloudapp.azure.com) |
| SQL |     |
| Provider (AD) | Fantomet |

![](./attachments/image-20210521-091803.png)

### QA

The QA (Staging) enviroment contains the current release branch and is running CI/CD based on checkinn on the release branch.

This enviroment is a production like enviroment, and is set up to mimic the production enviroment as far as possible.

|     |     |
| --- | --- |
| URL | [https://qa.bufdir.no](https://qa.bufdir.no) |
| SQL |     |
| Provider (AD) | Skytjenester |

![](./attachments/image-20210521-092623.png)

### Production

The production enviroment contains the solution based on the “master branch”. It is publically exposed to the population.

The hosting enviroment, skytjenester, is maintained by Løsningsutvikling from Bufdir, and CapGemini as a service partner.

|     |     |
| --- | --- |
| URL | [https://bufdir.no](https://bufdir.no) |
| SQL |     |
| Provider (AD) | Skytjenester |

![](./attachments/image-20210521-093020.png)