# Systemoversikt

# [Bufdir.no](http://Bufdir.no) (Nye)

![](./attachments/image-20230602-114538.png)

[Bufdir.no](http://Bufdir.no) er bygget etter MSOA (Moderne Service Orientert Arkitektur), hvor vi har splittet opp systemet fra en stor monolitt til en serie med tjenester og apier som samhandler for å levere en felles tjeneste.

Hvert system lever uavhengig av hverandre og kan oppdateres eller endres innenfor tekniske rammer uavhengig. Unntaket fra dette går på felles komponenter som feks Buflib, hvor endringer gjøres sentralt for å gi merverdi.

Systemet ble påbegynt i 2021 med fosterhjem som første område. Hoved siden er bygget med Optimizely (Episerver) som CMS, som er self-hosted. Støtte systemer (DSM, Statistikk, etc) og utenforliggende systemer ([noeharskjedd.no](http://noeharskjedd.no)) er bygget med Strapi som CMS løsning, da dette er en mer fremoverlent teknologi.

## Azure

Løsningen hostes på bufdir sin skyløsning i Azure.

Denne skytjenesten forvaltes av Løsningsutvikling og driftes av Capgemini. Tenanten (Azure) er bygget opp med hub&spoke topologi i en enterprise scale modell([https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/enterprise-scale/](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/enterprise-scale/) ).

Endringer i tenanten skal meldes til CAB (Som pr 02.06.2023 kjøres hver torsdag kl 13) og godkjennes der før det utføres. Det er viktig at det er nok detaljer i innmeldingen til at capgemini trenger å lete etter informasjon slik at dette går fort. Endringer som haster ta’s gjennom haste CAB.

## [Bufdir.no](http://Bufdir.no) (Gamle)

## DSM

### FSA

### BM

## Statistikk

## [Noeharskjedd.no](http://Noeharskjedd.no)