# System interactions; Fosterhjem

ROS, Oslo Kommune and [Bufdir.no](http://Bufdir.no) are connected through a set of API’s that cater to fosterhjem functionality.  
These sync meetings, locations and forms to and from [http://bufdir.no](http://bufdir.no) and their respective systems on the other end. These are ment to standardize and automate the very manuall process that were in place previously, and free ut valuable time for the people involved.

The interactions differ slightly from Oslo and ROS to bufdir, as ROS has a master data set on locations and postalcodes that [http://bufdir.no](http://bufdir.no) uses to map requests and offices to.