# Manuell konfig av url-er ved migrering prod-qa (qa-test)

Oppskrift for utviklere, superbruker, evt redaktører for korleis ein endrer slik at Optimizely viser til riktig visningslag etter migering av proddata til qa (eller qa-data til test)

## Felles

1 gå inn på admin - config - manage websites

## Test

her må URL Settes til

https://bufdirweb-test.azurewebsites.net/

![](./attachments/image-20230202-083051.png)

Under hostnames skal det være to rader

| **hostname** | **culture** | **type** | **info** |
| --- | --- | --- | --- |
| bufdirweb-test.azurewebsites.net | no  | Primary | angir at det er norsk som skal være språket når en går inn på bufdirweb-test |
| \*  | no  |     | denne må være her og brukes som fallback når optimizely ikke får treff på hvordan den skal koble språk opp mot adresse |

under Lisensfanen for Test skal det se slikt ut

![](./attachments/image-20230202-084105.png)

## QA

Lisensinfo -

Lisensen som er i bruk i QA og Prod er knyttet mot verdien “[ny.bufdir.no](http://ny.bufdir.no)”, i optimizely lisenssystem så må alle utgaver av et nettsted som deler lisens ha samme verdi - og den må være definert i URL feltet (tredje felt på manage websites) - for å da håndtere at prod og a egentlig har ulike web-adresser så må en definere dette under hostnames ved å lage en rad som representerer den faktiske adressen man er på og markere den som primary i tillegg må [ny.bufdir.no](http://ny.bufdir.no) være der.

![](./attachments/image-20230202-103955.png)

Under hostnames skal det være tre rader

| **hostname** | **culture** | **type** | **info** |
| --- | --- | --- | --- |
| ny.Bufdir.no | no  |     | Er visst nødvendig siden lisensen er knyttet opp mot ny.bufdir.no |
| bufdirweb-qa.azurewebsites.net | no  | Primary | Dette er nødvendig fordi ny.bufdir.no også er definert og man må si at det er bufdirweb-qa som er the real da |
| \*  | no  |     | denne må være her og brukes som fallback når optimizely ikke får treff på hvordan den skal koble språk opp mot adresse |