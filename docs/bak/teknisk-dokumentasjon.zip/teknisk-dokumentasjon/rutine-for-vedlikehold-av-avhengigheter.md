# Rutine for vedlikehold av avhengigheter

## Generelt

Prinsipielt ønsker vi å holde oss på siste versjon av avhengigheter både for å unngå sårbarheter, men også for å ikke skape stor jobb ved å måtte oppdatere mye på likt om man venter for lenge mellom hver gang man oppdaterer avhengigheter. Det er lettere å oppdatere hyppig enn å måtte ta oppdatering av mange avhengigheter på likt, særlig om nye major-versjoner med breaking changes er kommet siden sist.

Noen ganger er ikke dette mulig å etterfølge fordi vi det kan gå lang tid mellom hver gang man har allokert tid til å jobbe med respektive løsninger.

## Rutine for oppdatering av npm-moduler

### Fikse sårbarheter

Når man kjører en npm install, og ser at man har sårbarheter med alvolighetsgrad "high" eller "medium", så fikser man problemet som en del av tasken man er på, eller lager en ny unparented issue for å fikse problemet. Man fikser problemet fortrinnsvis ved å oppdatere pakker, men man kan også bruke `npm audit fix`, der det er markert som mulig.

Pass på å kjøre build, teste løsningen manuelt, se til at alt virker som det skal, og kjør automatiske tester uten feil før man oppretter PR på endringen.

Noen ganger vil det kreves oppdateringer som har breaking changes, typisk ved oppgradering til ny major version. Sjekk på nettet etter migrasjonsguider eller changelogger og fiks eventuelle breaking changes, før oppretting av PR.

### Praktiske kommandoer

*   `npm audit` - lister ut dependencies som er markert som sårbare, og markert hvorvidt det kan fikses automatisk
    
*   `npm audit fix` - la npm fikse problemet automatisk
    
*   `npx depcheck` - lister ut dependencies som ikke er i bruk (kan rapportere falske positiver ved at moduler er i bruk globalt uten eksplisitt import)
    
*   `npx npm-check-updates` - lister ut alle pakker som har nye oppdateringer og markerer med farge om den nyeste versjonen er av type major, minor eller patch. Kan brukes med parameter `-u` for å automatisk oppdatere package.json med nyeste versjoner for alle pakker - krever en npm install for å ha effekt på den kompilerte koden.
    

## Rutine for oppdatering av nuget-pakker

### Visual Studio

Høyreklikk på solution → Manage Nuget Packages for solution.

Pass på å teste løsningen etter oppdateringer. Spesielt ved oppdatering av Major-versjoner

### Praktiske kommandoer

*Nb: Gjør ikke oppdatering for deg, bare lister ut sårbarheter og utdaterte pakker*

`dotnet list package --vulnerable --interactive` *(standard i dotnet)*

`dotnet-tools` *(må installeres)*

`dotnet tool install --global dotnet-outdated-tool`

`dotnet outdated`