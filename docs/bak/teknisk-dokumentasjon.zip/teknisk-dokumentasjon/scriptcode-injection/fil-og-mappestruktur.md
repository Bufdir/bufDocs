# Fil- og mappestruktur

Fil- og mappestrukturen følger stort sett standard oppsett for bufdir-prosjekter men med litt avvik ettersom siste utvikling er stort sett refaktorering, justeringer og forbedringer av en ferdig implementert løsning. Hovedtrekket er at alt under `/src` mappa er delt i enten:

*   Components - komponenter, stateful eller view-components
    
*   API - alt med API kall å gjøre, i.e. CRUD operasjoner
    
*   Constants - konstanter eller variabler som skal vøre globalt tilgjengelig
    
*   Helpers - Hjelpefunksjoner og diverse metoder
    
*   Icons - Ikoner i .svg format
    
*   Layouts - Wrapper component som har `Header` og `Footer`
    
*   Pages - Page-komponenter
    
*   State - Globalstate
    
*   Style - CSS, SASS og generell styling av løsningen.
    

## Frontend

```
FSA.FRONTEND.REACT
📦 src
 ┣ 📂 api
 ┣ 📂 components
 ┃ ┣ 📂 buf-modal
 ┃ ┣ 📂 agreement-print-summary
 ┃ ┣ 📂 agreement-sharing-request
 ┃ ┣ 📂 authenticate
 ┃ ┣ 📂 auto-logout
 ┃ ┣ 📂 \[...\]
 ┣ 📂 constants
 ┣ 📂 helpers
 ┣ 📂 icons
 ┣ 📂 layouts
 ┣ 📂 locale
 ┣ 📂 pages
 ┃ ┣ 📂 my-page
 ┃ ┃ ┗ 📜 MyPage.tsx
 ┃ ┣ 📂 \[...\]
 ┣ 📂 state
 ┣ 📂 styles
 ┃ ┣ 📂 \[...\]
 ┃ ┗ 📜 custom.scss
 ┣ 📜 App.tsx
 ┗ 📜 AppRoutes.tsx
```