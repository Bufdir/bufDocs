# Git branching strategi / Pipelines

![](./attachments/wtaoD9WAi~4b%3Fa=1174&x=193&y=21&w=1034&h=1257&store=1&accept=image%2F*&auth=LCA%20d4ea98e9cb9a778cfa1c09dfd12fb6c9d654930a-ts%3D1635853500)

[Bufdir.no](http://Bufdir.no) project bases its branching strategy on the GitFlow model ([Gitflow cheat sheet](https://danielkummer.github.io/git-flow-cheatsheet/)).

The CD is set up as follows:

| **Branch** | **Test** | **QA** | **Prod** |
| --- | --- | --- | --- |
| Feature🔱(CI) |     |     |     |
| bugfix🔱 |     | (✔️) |     |
| develop🔱 | ✔️  |     |     |
| Release🔱 | (✔️) | ✔️  | (✔️) |
| Hotfix🔱 | (✔️) |     | (✔️) |
| Main🔱 |     |     | ✔️  |

(✔️)\* = Triggers release to enviroment indirectly when merged back to parent.

## Setting up git flow

Run `git flow init` first:

```
git flow init
```

Typ in `main` as branch for production releases

```
Branch name for production releases: \[\] main
```

The rest are default\* settings:

```
How to name your supporting branch prefixes?
Feature branches? \[feature/\]
Bugfix branches? \[bugfix/\]
Release branches? \[release/\]
Hotfix branches? \[hotfix/\]
Support branches? \[support/\]
Version tag prefix? \[\]
```

\*Press enter to select the default naming.

## The normal cycle

The normal cycle of branches is that we run our development cycle through feature🔱 branches taken from Develop🔱 branch.

```
git flow feature start '#1234-some-description'
```

which is merged back to the develop branch though a PR.

```
git flow feature publish
```

When a sufficient ammount of development is completed to warrant it, or the Test Lead requests it, we make a Release🔱 branch.

```
git flow release start x.x.x
```

This branch is deployed to the QA enviroment, where a regression test is run.

```
git flow release publish
```

Any bugs reported on this test cycle should be fixed by branching a bugfix🔱 branch from the Release🔱 branch. Once the Release🔱 branch is at a comfortable and acceptable state, it is then finished through a `git flow release finish`, and merged back in to both develop🔱 and main🔱, and then deletes the the release🔱 branch from both remote and local.

```
git flow release finish
git checkout develop
git push
git checkout main
git push
git push --tags
```

This triggers a push to production from the trigger on the main🔱 branch, thus rolling it out to prod enviroment staging slot.

After this, the two slots on production enviroment web app needs to be swapped in order for the changes to go live to users.

## Hotfix

Hotfix is done directly from the main branch. We use this when we require an immidate fix to production problems, that can not go through the normal cycle. This is done through the gitflow start hotfix command, from the main branch, and then merged back to both develop and main through the gitflow hotfix finish command.

```
git flow hotfix start '#1234-my-description'
```

## Bugfix

Bugfix is done through a bugfix branch created on the Release branch that is currently alive.

```
git checkout release/x.x.x
git checkout -b bugfix/#123-my-description
```

When the work is complete the bugfix branch is then merged back to **the release branch** through a PR. This makes its way to develop and main through the release branch’s finishing steps. *This is a deviation from the normal gitflow process.*

## Versioning

We follow [semver](http://semver.org/spec/v2.0.0.html) and keep a [changelog](https://dev.azure.com/Smidig/Bufdir.no/_git/ny.bufdir.no?path=/changelog.md).

The version consists of three numbers representing, in order, **major**, **minor** and **bug**, so we can immagine a version 1.2.3 where 1 is the major version, 2 is the minor version and 3 is the bug version. For each release we bump one of these numbers based on these criteria:

*   Major: we introduce changes that may affect other systems that rely on our code.
    
*   Minor: we introduce new features to other systems that rely on our code.
    
*   Bug: we do not introduce new features or breaking changes to other systems that rely on our code (but may, or may not, introduce fixes to existing features).