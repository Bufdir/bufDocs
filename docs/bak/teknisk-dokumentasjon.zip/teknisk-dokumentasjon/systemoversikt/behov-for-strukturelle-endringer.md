# Behov for strukturelle endringer

## Ordliste

### Tett kobling

Tett kobling mellom handler om når koden er skrevet på en slik måte at mange funksjoner av koden er avhengige av hverandre. Man må ha derfor ha dyp innsikt i flere lag av løsningen for å endre på funksjonalitet. Dette er ikke ønskelig fordi man øker kompleksiteten i løsningen, og gjør nyutvikling tregere, og det blir vanskeligere å bytte ut deler av løsningen ved behov.

### SSR

Står for "Server side rendering", og handler spesifikt om å kompilere frontendkode på serversiden for å kunne cashe større deler av koden og ta bort belasting av å kjøre kode fra klientene.

### Stack

Referer til flere deler av løsningen, i dette tilfelle frontend og backlend.

### Legacy

Legacy-kode er kode som ikke har blitt oppdatert over tid, og er vanskeligere å lage nye features i, fordi vi ikke kan bruke nyvinninger som hjelper på produktivitet. Elding av kodepraksis gjør det også vanskeligere å skaffe folk som kan jobbe med koden over tid.

I tillegg vil sikkerhet bli en større og større risiko fordi markedet beveger seg mellom oppdaging av sikkerhetsrisiko og fiksing av de aktuelle risiki.

## 2020

### Kodens tilstand

Deler av frontend var skrevet med React, men med skreddersydd, og noe rotete, mellomlag mellom frontend og episerver.

Mye av koden hadde tett kobling mellom frontend og backend. En god del av fundamentet for frontendkoden, mest nevneverdig routing og "content areas", er styrt av Episerver (nå "Optimizely").

Det var ingen SSR på frontendkode.

### Grep for å forbedre koden

Vi ønsker å øke separering mellom frontend og backend, hovedsaklig fordi vi hadde spesialister på hvert område på teamet, og dette ville øke produktiviteten på begge sider av "stacken". Det ville også tillate frontend og ta større eierskap av frontendkoden ved å kunne flytte så mye som mulig inn i et moderne frontend-rammeverk (react).

Vi ønsket å migrere frontend over til react, kjøre frontendkode med SSR, og minske kompleksiteten i mellomlaget mellom react og episerver - stegvis. For å få til dette besluttet vi at episerver fortsatt skulle håndtere de sidene av frontend som ville tatt mest arbeid å gjenskape i react, og heller migrere en og en komponent over tid.

Å kjøre CMSer 100% headless var blitt en standard på dette tidspunktet, men episerver hadde ingen god løsning for dette, som bidro til å gjøre et slikt hopp ville vært for stort.

For å kunne kjøre enkeltkomponenter med SSR i kontekst av episerver så trengte vi noe for å kunne kjøre SSR i .NET kode. Vi landet på å bruke en pakke som heter [http://ReactJS.net](http://ReactJS.net) .

### Resultat av grep

Resultatet av grepene som ble gjort er at man lettere kan bytte ut og oppgradere deler av løsningen, og at frontend og backlend-spesialister kan fokusere på sine områder og jobbe mer effektivt.

Dette har vi nytt godt av i årene etter endringen.

## 2023

### [http://ReactJS.net](http://ReactJS.net) deprecated

Den siste tiden har vi ventet på oppdateringer av [http://ReactJS.net](http://ReactJS.net) for å få støtte for siste versjon av React.

De siste årene har flere løsninger for å kjøre frontend 100% isolert med SSR på frontendsiden (teknisk sett på serversiden, men i samme økosystem som frontend - javascript/nodeJS). Blandt de mest populære har vi NextJS som kjører reactkode.

14 September annonserer [http://ReactJS.net](http://ReactJS.net) at de ikke kommer til å oppdatere, og anbefaler å heller ta i bruk mer etablerte praksisser som f.eks NextJS (se lenke under til annonseringen).

[https://github.com/reactjs/React.NET/issues/1315](https://github.com/reactjs/React.NET/issues/1315)

### Konsekvenser

Dette fører til, om vi ikke gjør noen større grep, vi ikke kan oppdatere React til siste versjon, eller noen versjoner som kommer etter gjeldene. Dette vil igjen gjøre at vi ikke kan følge utviklingen i markedet, og løsningen vil kunne bli "legacy". Dette vil påvirke utviklingshastighet og sikkerhet i eskponesiell fart.

### Anbefalinger

Vi anbefaler å migrere all frontend over til NextJS. Dette vil ta en kost i utviklingshastighet i en periode, men vil gi bedre utviklingshastighet på lengre sikt, enn ved å ikke gjøre noe med problemet.

Vi vil også anbefale å vurdere bytte til et CMS som er bygget for moderne headless utvikling, da episerver/optimizely fortsatt ikke er optimisert for denne arbeidsflyten.

### Tilleggsinformasjon

#### Workaround på kort sikt

Vi kan ta i bruk egenutviklet kode som løser SSR, men dette blir vi da nøtt til å vedlikeholde selv, og kan potensielt kreve mye arbeid å oppdatere etterhvert som andre deler av systemet får oppdateringer.

Vi vil uansett anbefale å gå over til noe tilsvarende NextJS på lengre sikt uansett.

#### Progress Optimizely

Utviklerne bak episerver/optimizely har de siste årene laget noen eksempler på hvordan man kan jobbe headless med CMSet. Det finnes spesifikke eksempler hvor NextJS er brukt. Eksemplene knytter fortsatt CMS-praksisser inn i frontend, så vi anbefaler ikke å kopiere eksemplene direkte, men vi kan ta biter av det. I tillegg er denne måten å gjøre ting på låst bak Optimizely DXP, så vi har ikke mulighet til å bruke det i dag.