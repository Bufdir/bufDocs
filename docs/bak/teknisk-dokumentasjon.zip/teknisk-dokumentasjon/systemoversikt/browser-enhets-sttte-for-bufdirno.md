# Browser / enhets -støtte for bufdir.no

**Browser / enhets -støtte for** [http://bufdir.no](http://bufdir.no) **og DSM** 

Sist oppdatert. 19.09.2023, NSA  

**Browserlist** 

Det tas utgangspunkt i denne listen for støttede nettlsere: [https://browserl.ist/?q=last+2+versions+and+%3E+1%25+in+NO+and+not+dead+and+not+ie+11](https://browserl.ist/?q=last+2+versions+and+%3E+1%25+in+NO+and+not+dead+and+not+ie+11)  

Browsere fra listen vil få moderne layout, animerte effekter og interaktive moduler. Eldre nettlesere som IE 11 vil kun få funksjonell støtte. 

Nettstedet / appen vil ikke se identisk ut overalt. Selv noe så grunnleggende som et inputfelt vil oppføre seg forskjellig fordi hver enhet har et annet OS, nettleser, skjermstørrelse, muligheter osv, men ideelt sett vil kjerneapplikasjonen forbli lik. 

 **Data hentet fra GA for perioden 1 jan – 1 juli 2023** 

 **Nettlesere** 

![](./attachments/image-20230919-155459.png)

**Safari** 

![](./attachments/image-20230919-155101.png)

**Skjermstørrelser** 

![](./attachments/image-20230919-155625.png)

**OS** 

![](./attachments/image-20230919-155545.png)

**Data hentet fra GA for perioden 1 august – 1. oktober 2019** 

|     |     |
| --- | --- |
| Browser | Prosent |
| Safari | 37% |
| Chrome | 35% |
| Safari(iOS) | 9%  |
| Android Webview | 6%  |
| Edge | 5%  |
| Samsung Internet | 5%  |
| Totalt: | ≈97% |

**Skjermstørrelser** 

|     |     |
| --- | --- |
| Skjermstørrelser | Enhet |
| 375px | Mobil (iPhone 6 og nyere) |
| 576px | Stor mobil |
| 768px | Tablet |
| 992px | Liten laptop |
| 1200px | Laptop |
| 1950px | Stor skjerm |