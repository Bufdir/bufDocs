# Script/code injection

Vi blir av og til bedt om å legge inn scripts fra tredjeparter. Eksempelvis for å legge inn funksjonalitet som er laget av andre team, på bestilling av andre avdelinger. Annet eksempel er fra GTM for å kunne dra ut målinger og sende til facebook, instagram, GA osv.

Injected kode fra tredjeparter via scripts er uønsket da det faller utenfor forvaltningen til utviklingsteamet. Det vil si at det ikke blir oppdatert eller kontrollert.

  
En av farene med injected kode er avhengigheter til rammeverk som fjernes i utviklingsforløpet (feks jquery), at pakker som benyttes i den injecta koden gjør ting som vi ikke har kontroll over (drar med seg andre ting i injectionen, som feks sårbarheter eller usikrede pakker), eller at den injectede koden fører til tregheter og feilsituasjoner i løsningen.

Vi mister kontroll over koden, og får ikke sikret injected code gjennom samme utviklingsløp som resten av vårt arbeid.

Vi vil derfor avslå alle forespørsler om å injecte kode på denne måten, og vi vil starte et arbeid for å fase ut eksisterende scripts som finnes i løsningen.

Skal det aksepteres funksjonalitet fra tredjeparter, må det inngå som en del av vår kodebase, enten direkte, eller via instansiering av nuget/npm-pakker fra etablerte kilder, som vi stoler på.