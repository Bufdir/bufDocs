# FSA Refaktorering (Sprint 50)

## Innledning

Vi ønsker å få fremgang på implementering av “redesign” på ny.bufdir (full rewrite av eksisterende funksjonalitet fra gamle [http://bufdir.no](http://bufdir.no) med nytt design), samtidig som vi ser at koden på FSA trenger mye oppmerksomhet før eventuelle oppgaver skal utføres der.

### Redesign

Design har vært flinke til å gjenbruke designelementer fra område til område på “redesign”, og frontend har vært flinke å lage gjenbrukbare komponenter. Dette resulterer i at område som nå skal implementeres, “familie”, kan gjenbruke frontend fra området fosterhjem, som allerede er implementert.

Før vi får nye skisser fra design på nye områder som skal implementeres, så har vi ikke så mye å plukke som inngår i “redesign”-løpet på frontend, men vi ser at det er behov for bedre testdekning på frontend og fiksing av bugs som er registrert på det som er implementert til nå.

### FSA

Vi har brukt en del tid til nå på å bytte ut gammelt design med nytt, bytte ut gammelt komponentbibliotek med nytt og lage noen nye features (f.eks print av avtale fra “min side”), og vi har “mocket” litt av det som skal komme relatert til “begjær mekling”.

Vi har også innført system for strukturert dataflyt og håndtering av språkstrenger, men det er ikke implementert i hele koden.

Underveis i arbeidet har vi støtt på utfordringer som indikerer at koden sårt trenger et stort løft. Det er lite gjenbruk av kode, samtidig som kode på tvers er for sterkt knyttet sammen og mangler struktur. Det medfører uforutsigbare resultater når man utfører endringer. Det gjenstår fortsatt strukturering av hele kodebasen, som vil kreve fokusert arbeid i en periode. Vi ser derfor et stort behov for å jobbe strukturert med å rydde opp i koden. Vi skal ikke prøve å lage applikasjonskoden perfekt, men vi vil opp til et minimumsnivå av forventet kodekvalitet, samt testdekning.

#### Positive effekter av å utføre et løft på FSA

*   Kortere feedbackloop mellom design, frontend og backend i arbeid med FSA/Begjær Mekling, siden frontend ikke blir liggende etter pga vanskeligheter i koden - med andre ord, mer agil arbeidsform.
    
*   Mer stabil tjeneste, med færre bugs.
    
*   Økt utviklingshastighet i fremtiden ettersom det vil være lettere for utviklerne å navigere i koden.
    

#### Konsekvens av å ikke utføre et løft på FSA

*   Om dette løftet ikke utføres, så vil det resultere i at nye features vil ta mye lengre tid å implementere, og alle nye features vil ha høyere risiko for å skape bugs.
    

### Anbefaling fra frontendutviklerne

På bakgrunn av manglende frontendoppgaver på “redesign” og behov for et løft på kodekvaliteten på FSA anbefaler frontendutviklerne å ha én ressurs fast på FSA en periode, for å sikre at løsningen er mer klar enn i dag til å få nye features, når den tid kommer. (“Nye features” gjelder også nyutvikling relatert til begjær mekling i denne sammenheng.)

Vi ønsker fortsatt å ha fokus på [ny bufdir](http://ny.bufdir.no) og anbefaler å ha en frontendutvikler til å bistå med backendarbeid, og en til å skrive tester og fikse bugs på [ny bufdir](http://ny.bufdir.no) , inntil nye skisser på nye områder er på plass.

## Estimater

Estimat på total refatorering

*   1 til 2 mnd, en utvikler fulltid.
    

*Notis: Endringer i design kan fjerne behov for funksjonalitet, så unødvendig å rydde opp i og bør identifiseres så tidlig som mulig*

## Hva bør være på plass før kodeløft

1.  En minimal ende-til-ende-test, skrevet i kode, med dokumentasjon og klare (swimlane) diagrammer.
    
2.  Fikse bugs, og sikre at signering via Digipost er mulig
    

## Strategi for kodeløft

*   Først starte på “rammenivå” med de mest generelle strukturene og rammene, som f.eks:
    
    *   Page Layout
        
        *   State management / hoisting
            
    *   Login
        
    *   Oversettelser
        
    *   Generell feilhåndtering (“systemmeldinger”)
        
*   Jobbe seg innover og identifisere og enkapsulere funksjonelle domener ("korte ned lange spagetti-tråder og strukturere dem i områder/ravioli")
    

## Operasjonell plan

1.  Utføre **påbegynt** rydding (State + Page Layout) - Flemming
    
2.  Fikse **bugs** og sikre signering for så å lage komplett ende-til-end testing - Kuda, Flemming
    
3.  **Kartlegge** flyt - Kuda, Flemming
    
    1.  Trekke inn designer?
        
        1.  MaterialUI-typ "funksjonelle UI komponenter" for bruker-interaksjon
            
            1.  Modaler
                
            2.  Toasts e.l for systemmeldinger
                
            3.  Header-meny
                
            4.  Merk! Utfylling av skjema kan trenge egen meny ref. “Tøm feltene”-knappen
                
            5.  mm
                
4.  **Identifisere** områder som ikke påvirker flyten ende-til-end testingen (Flemming, Kuda)
    
    1.  Kalendere
        
    2.  PrintArea
        
    3.  Annen spagetti som bør enkapsuleres
        
        1.  State,
            
            1.  Hoisting,
                
        2.  Mellomregninger
            
            1.  Viktige variabler
                
5.  **Prioritere** områder som skal enkspsulerer - Simon, Kuda, Flemming
    
6.  **Enkapsulere** områder - Flemming, Kuda
    
    1.  Flytte relatert kode / loggikk inn i egne filer / funskjoner
        
    2.  Implementere gjenbruk av disse
        
    3.  Itterere over a) og b) til strukturen i selve flyten trer frem og vi oppnår den kontrollen over koden vi er ute etter
        
7.  **Refaktorere** kode internt for de enkapsulerte områdene - Flemming, Kuda
    

## Status og hva vi vet kommer av nyutvikling

FSA og Begjær Mekling (BM) kjører på samme løsning. BM er ikke ennå påstartet, kun mocket overfladisk inn i frontend.

Implementering av løsning for begjæring av mekling kommer, deretter er det planlagt redesign (ikke til å forveksle med “reskin” som allerede er utført) med ux-løft og restrukturering av innhold på FSA.