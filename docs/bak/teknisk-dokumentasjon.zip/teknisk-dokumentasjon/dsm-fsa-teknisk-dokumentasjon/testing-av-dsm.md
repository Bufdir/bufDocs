# Testing av DSM

Her ligger alt du skal trenge for å teste FSA. For innlogging med bankid er det best å bruke MinID med testbrukere nedenfor.

### Nyttige linker

FSA Dev APP: [https://fsa-app-dev.azurewebsites.net/](https://fsa-app-dev.azurewebsites.net/)

FSA Feature APP: [https://fsa-app-feature.azurewebsites.net/](https://fsa-app-feature.azurewebsites.net/)

Generere midlertidige e-postadresser (gratis for public inboks): [https://www.mailinator.com/](https://www.mailinator.com/)

### Innlogging (via MinId)

[https://docs.digdir.no/docs/idporten/idporten/idporten\_testbrukere.html](https://docs.digdir.no/docs/idporten/idporten/idporten_testbrukere.html)

**Fødselsnummer**: <velg nedenfor>

**Passord**: password01

**Engangskode**: 12345

## Testbrukere

|     | **Far (f.nummer)** | **Barn** | **Mor (f.nummer)** | **Kommentarer** |
| --- | --- | --- | --- | --- |
| 1   | 5047042781 | 1 Barn - FELLES | 05047149438 |     |
| 2   | 20078900580 | 3 Barn - FELLES | 19128600658 |     |
| 3   | 12106600153 | 1 Barn - MOR | 12117000247 |     |
| 4   | 01096000533 | 1 Barn - FAR | 02086300454 |     |
| 5   | 19017649550 | 1 Barn - MOR | 19017549459 |     |
| 6   | 17107749713 | 5 Barn - FELLES | 17117749460 | *DIFI kontoen til mor er låst, så bruk farens.* |

Merk: noen brukere (f. nummere) kan være deaktivert, låst eller rett og slett inaktive. Prøv i så fall andre testbrukere eller besøk ID-porten lenken øverst for oppdaterte testbrukere.