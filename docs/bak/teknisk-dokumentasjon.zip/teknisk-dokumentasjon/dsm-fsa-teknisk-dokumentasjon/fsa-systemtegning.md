# FSA systemtegning

![](./attachments/FSA_system-20231106-133519.gif)