# Legacy dokumentasjon

Her er alt av tidligere dokumentasjon fra første implementasjon. Merk at noe kan være mangelfull, men dette er foreløpig det som vi har klart å finne frem.

Slik så det ut først:

![](./attachments/image%2092.png)

### Opprinnelig teknisk dokumentasjon

[DSM-FSA\_Technical\_Docume…](/wiki/spaces/BUF/pages/2414510104/Legacy+dokumentasjon?preview=%2F2414510104%2F2417328145%2FDSM-FSA_Technical_Documentation.pdf)

Diagramener nedenfor er hentet fra teknisk dokumentasjon.

#### Gammel flyt diagram:

![](./attachments/Screenshot%202022-05-10%20at%2012.12.39.png)

#### Gammel Integrasjons diagram:

![](./attachments/Screenshot%202022-05-10%20at%2012.22.19.png)

| **Tjeneste** | **Beskrivelse** |
| --- | --- |
| ID-porten digipost | Innloggingsløsning for offentlige tjenester. |
| Digipost | Ekstern tjeneste i bruk i FSA for digitalsignering |
| Azure Api Management | API-gateway; fasade mot Bufdir interne API. |
| Azure Web App | Plattform for å kjøre webtjenestene i DSM (f.eks. FSA). |
| Azure SQL | Lagring av data fra DSM-tjenester (f.eks. data fra foreldresamarbeidsavtale). |
| Cosmos DB | Lagring av teknisk logginformasjon. |
| Key Vault | Sikker lagring av nøkler |
| Bambus Integration App Service | Tjeneste som henter data fra ‘Det sentrale folkeregister’ (DSF) |
| Notification (Email) App Service | Tjeneste som sender E-postvarsler |

### Legacy komponent bibliotek DEPRECATED

[Bufdir Component Library Docs (Deprecated)](https://stolddsmstyleguide.z1.web.core.windows.net/)

### Annen tidligere/legacy dokumentasjon

#### Innsiktsfase

Testscript av FSA - 2019

[FSA\_2019\_Test\_foreldresa…](/wiki/spaces/BUF/pages/2414510104/Legacy+dokumentasjon?preview=%2F2414510104%2F2418901000%2FFSA_2019_Test_foreldresamarbeidsavtalen_sep_2019.pdf)

Brukertest funn 2019

[FSA\_2019\_Brukertest\_Funn…](/wiki/spaces/BUF/pages/2414510104/Legacy+dokumentasjon?preview=%2F2414510104%2F2418638874%2FFSA_2019_Brukertest_Funn.pdf)

FSA Geriljatest 2019 v/ Making Waves

[FSA\_2019-Geriljatest.pdf](/wiki/spaces/BUF/pages/2414510104/Legacy+dokumentasjon?preview=%2F2414510104%2F2418311173%2FFSA_2019-Geriljatest.pdf)

#### Diverse andre dokumenter:

Feil fra test FSA - 2021

[Feil fra test ny FSA 05 …](/wiki/spaces/BUF/pages/2414510104/Legacy+dokumentasjon?preview=%2F2414510104%2F2418901006%2FFeil+fra+test+ny+FSA+05+02+2021.xlsx)