# Utviklingsmiljø

Her finner du informasjon for å oppsett av utviklingsmiljø.

## Step 0: Install .NET

Trying all fancy installers failed, so ended up doing it manually.

1.  Download the version you think you need from here: [https://dotnet.microsoft.com/download](https://dotnet.microsoft.com/download)
    
2.  Move it to where you want the unpacked files to reside, e.g `/opt/dotnet-sdk-3.1.101` and unpack it there `tar xvzf dotnet-sdk-X.X.X-linux-x64.tar.gz .`
    
3.  Add the folder you unpacked it in to the `PATH`, e.g `~/.bashrc`:
    
    ```
    \# .NET
    export PATH=$PATH:/opt/dotnet-sdk-3.1.101
    
    ```
    
4.  Restart the shell or `source ~/.bashrc` to make the PATH-export take effect (or just open a new shell)
    

*   Doublecheck you got it right
    
    ```
    which dotnet
    ```
    

## Step 1: Clone repository/project

Clone project from [FSA Repository](https://dev.azure.com/Smidig/Bufdir.no/_git/FSA)

## Step 1. Build project

## Build project

Do `sudo journalctl -n` to tail and error output in a seperate terminal while building to see any swallowed `dotnet` output.

1.  Cd into the folder where your `.csproj`\-file is and run `dotnet build --interactive`
    

If it fails, re-run it.

### Trobleshooting

*   Version mismatch, `Could not execute because the application was not found or a compatible .NET SDK is not installed.`
    
    *   Check the output and install the correct version by starting from step 1 above.
        
*   Resolve external `Nuget Feed` dependencies
    
    *    [https://github.com/Microsoft/artifacts-credprovider](https://github.com/Microsoft/artifacts-credprovider)
        
*   Mac/iOS run `sh -c "$(curl -fsSL https://aka.ms/install-artifacts-credprovider.sh)"`
    
*   Change your org login using `Azure CLI`, [https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt)
    

## Step 2: Run project

### FSA.Frontend

1.  `npm run build`
    

### [FSA.Backend.Web](http://FSA.Backend.Web)

1.  Install `Azure-CLI` to sign in and set the credential to allow accessing online resources needed to run the solution
    
    1.  `curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash`
        
2.  Log in to your Azure account
    
    1.  `az login --tenant <Fantomet Tenant ID>`
        
3.  In the folder where you built the project run
    
    1.  `dotnet run`
        
4.  Run a profile from `launchSettings.json`:
    
    1.  `dotnet -d run --launch-profile "<PROFILE_NAME>"`
        
    2.  `dotnet -d run --launch-profile "FSA.Backend.Web"`
        
        1.  NOTE! Seems appending flag `--stdoutLogEnabled` pipes (at least) extra warnings to the console.
            

The project is now running on the port specified in the profile that launched.

#### Troubleshooting

1.  Set billable subscription to use for your account
    
    1.  `az account set --subscription "Utvikling"`
        
2.  Just wait 10 minutes and retry
    

## Notable configuration files

1.  `<PROJECT>/Properties/launchSettings.json`
    
2.  `<PROJECT>/appsettings.json`
    
3.  `<PROJECT>/appsettings.Development.json`
    
4.  `<PROJECT>/Constants.cs`