# FSA - Tekniske avklaringer

## Redirects tilbake fra eksterne løsninger

Ved **reject, completion** (“Exit-urls”) på signeringen ([https://difitest.signering.posten.no/signere/](https://difitest.signering.posten.no/signere/)) blir man sendt tilbake til en API-url:

*   https://<OUR\_DOMAIN>/api/digitalsigning/rejection/
    
*   https://<OUR\_DOMAIN>/api/digitalsigning/completion/
    

Dette er samme path / controller som vår frontend benytter for sine kall

1.  Det burde vært egne controllers / paths for callbacks fra eksterne endepunkter
    
2.  Et API-kall burde i utgangspunktet ikke benyttes til en intern redirect
    

### Autentisering av Exit-urls

Disse kallene krever autorisering.

*   Dersom brukere **ikke** logger inn i FSA etter signering hos posten, hvordan ivaretae synkronisering mellom posten og FSA? - Dvs hvordan få oppdaterit avtalestatus i FSA?
    
    *   Antaglig shedules det sjekking det mot status-apiet hos posten [https://signering-docs.readthedocs.io/en/latest/client-integration/direct-flow.html#step-2-signing-the-document](https://signering-docs.readthedocs.io/en/latest/client-integration/direct-flow.html#step-2-signing-the-document)
        

## Login for flere løsninger under DSM

FSA og BM kjører på samme backendløsning, og har samme login. Dersom det kommer en “app” til som skal under DSM, men ikke kjører på FSA-løsningen, hvordan løses dette?

## Login med signeringslenke (AgreementSharingRequest “/?asr=xxxx”)

Signeringslenke med querystring \`/?asr=” trigger en redirect til Idporten, men hva skjer med `asr` verdien etter det?

*   Hvordan brukes `asr`?
    
    *   Blir den brukt backend før IdPorten?
        
    *   Trengs den et sted etter IdPorten
        
    *   Kort sagt, hvor blir den plukket opp?
        
*   Skal det være én redirect til ved retur fra IdPorten eller holder det å lande på `MyPage`
    
    *   `MyPage` viser en infoboks om noen har delt en avtale med deg
        

# Redirects / Ajax standard

Flere ajax requester får tilbake en JSON struktur inneholder props

```
isRedirect: Boolean
redirectUrl: String
```

FSA er ikke en SPA da redirect stort sett ikke bruker `React Router`, men heller setter `window.location`. Dett gjør at hele løsningen lastes på nytt i de fleste tilfeller. Window redirects plukkes opp i FE ved `isRedirect: true` i response fra BE.

Dette gjør det utrolig vansklig å følge flyten i appen fordi app-state brytes ved nesten hvert eneste handling, og React Router benyttes da kun som en “en-gangs sluse” for den nye staten som kommer fra BE.

### Løsning

I `FSA.Backend.Web/Model/FsaResult.cs` ligger en wrapper-klasse for API reponsene. Fas ut bruken av denne med en mer standarister og/eller SPA-vennlig wrapper ala JSONAPI. Dette må drives av endringer client-side ved transisjon til en fullverdig SPA.

**Status:** Implementert

**Todo**: Backenders bør se over. Med JSON API er det letter i frontend å forholde seg til reponser, men fortsatt er det litt avklaringer igjen rundt om vi bør bruke feks `error: BadRequest` for å fortelle om bruker har samtykket, eller ikke har logget inn, når `data: prop: true|false` kutter ned enormt på reposnshåndtering i frontend…

# Kjøring av FSA.Digipost og FSA.Data.EF

`$ dotnet run`

`/usr/local/share/dotnet/sdk/3.1.415/Microsoft.Common.CurrentVersion.targets(1177,5): error MSB3971: The reference assemblies for ".NETFramework,Version=v6.0" were not found. You might be using an older .NET SDK to target .NET 5.0 or higher. Update Visual Studio and/or your .NET SDK. [/Users/kudakwashechambwe/dev/FSA/FSA.Data.EF/FSA.Data.EF.csproj]`

`The build failed. Fix the build errors and run again.`

**Foreslått løsning**: Få en backender til å se på dette?

# Virkesomhetssertifikat

Trengs dette? Hvor finnes dette? For dokumentasjonen lyder slikt:

“Integrasjonen krever et virksomhetssertifikat for å fungere, og dette virksomhetssertifikatet må installeres på maskinen som hoster FSA- applikasjonen. Sertifikatet er lagt til i keyvault, og installeres dynamisk i host-maskinen ved startup.“

Dette gjelder signering av avtalen.

# AgreementForm

## Tøm feltene

```
src/components/clear-fields-modal/ClearFieldsModal.tsx
```

Tømmer alle feltene i formen ved å sende et “tomt” skema til backend for lagring, og så laste alt på nytt.

*   Hvor skal denne ligge i UI design-messig?
    
*   Skal det andre lignenede “knapper” inn i UI?
    

## Feilmeldinger

```
src/components/buf-modal/BufModal.tsx
```

Er en egen modal for å vise system- og feilmeldinger relatert til formen.

*   Alt for tett knyttet opp mot dårlige strukturer (med forvirrende navngivning) i AgreementForm
    

## SaveForm - encryption

Data ved form submit blir kryptert.

```
src/helpers/encryptionLib.tsx
```

De samme dataene sendes tilbake, og hentes alle andre steder, ukryptert

*   Hvorfor krypteres det kun på innsedning av data?
    
    *   Kan dette droppes siden samme data sendes ukryptert alle andre steder?
        

## IncludePhone

Blir kun sjekket på, blir aldri satt til noe annet enn default verdi.

*   Trengs den backend?
    
*   Er det noe annet “phone”-relatert den skulle blitt hentet fra?
    

## Footer - BufdirFramework

BE er satt opp til å kreve login på **alle** api-kall. Dette inkluderer henting av innhold i footeren.

*   Skal det være sånn at innhold i footer ikke vises med mindre man er logget inn?