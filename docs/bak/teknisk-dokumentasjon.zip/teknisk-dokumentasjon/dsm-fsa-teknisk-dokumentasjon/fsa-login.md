# FSA - Login

# Mounting av FSA appen

Inngangen til FSA-løsningen er fra en bufdir-side (EpiServer / Optimizely) på url `https://www.bufdir.no/Familie/Samlivsbrudd/mekling_og_avtale/Foreldresamarbeidsavtale/`

Herfra lenkes det til `https://fsa.bufdir.no` hvor løsningenen ligger.

## Ikke logget inn

Kladd fra [Shamrez Iqbal](https://bufdir.atlassian.net/wiki/people/557058:e9359847-9d7f-457f-a8f1-c02b7c7bf60e?ref=confluence) ([https://excalidraw.com/#room=5cffc0705f959dd2e5e4,ErPuSyEklzNzT7u39Khb9w](https://excalidraw.com/#room=5cffc0705f959dd2e5e4,ErPuSyEklzNzT7u39Khb9w))

![](./attachments/image-20221001-112808.png)

Backenden redirecter rett til Id-porten på url

```
// Prod
https://idporten.difi.no/opensso/UI/Login
?realm=/norge.no
&spEntityID=oidc.difi.no
&service=IDPortenLevel3List
&goto={
    http://idporten.difi.no/opensso/SSORedirect/metaAlias/norge.no/idp5
    ?ReqID=\_13923408ef415d139cfd640484f3449d
    &index=null
    &acsURL=https://oidc.difi.no:443/idporten-oidc-provider/assertionconsumer
    &spEntityID=oidc.difi.no
    &binding=urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST
}
```

Etter login sendes man tilbake til `https://fsa.bufdir.no/`.

# Autentisering

FSA Backenden krever authentifisering for alle (kjente) endepunkter.

Da er det mulig med optimistisk eller pessimisteisk henting av data, hvor

**Optimistisk** - Starter alle requester, og kansellerer / forlater dem dersom /autheticate gir status 401 Unauthorized

**Pessimistisk** - Avventer /autheticate før noe annet kjøres.

Pessimistisk tilnæriming git en bedre oversikt over hva som faktisk skjer, så derfor har `<Login />`

blitt gjort om til `<Authenticate>[...content]</Authenticate>`

## OpenID / OAUTH - Pessimistisk flyt

Endepunktet `/login` er (i praksis) ikke lenger i bruk fordi `<Authenticate>` sjekker `/api/home/authenticated` på alle sine routes, og ved status 401 redirecter til backendens egentlige login url, `/account/login`.

## Wishlist ![(smile)](https://bufdir.atlassian.net/wiki/s/-1837753547/6452/ed9338f6a1977ef915cd6811188fcb147a29deb2/_/images/icons/emoticons/smile.png)

Dersom strapi håndterer oversettelser, hva gjenstår av funskjonalitet i EpiServer backenden?

*   Om det kun er login håndtering, kunne dette også blitt flyttet til et annet sted / en annen løsning?
    

*   Pros / cons?