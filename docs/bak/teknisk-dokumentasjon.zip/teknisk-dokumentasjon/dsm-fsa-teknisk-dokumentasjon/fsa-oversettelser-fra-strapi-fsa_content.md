# FSA - Oversettelser fra Strapi "FSA_Content"

# Innledning

Oversettelser hentes pr i dag fra to steder

1.  Systemdomene - må være tilstede ved lasting av siden
    

1.  Innholdsdomene - kan lastes asynkront
    

Strapi skal ta over oversettelser for innholdsdomenet.

Det er en god del opprydding igjen på FE koden i FSA, og vi trenger bedre kontroll over oversettelsene. Derfor foreslås at

1.  Vi lager lokal kopi av oversettelsene for innholdsdomenet, json-filer.
    

1.  Vi oppdaterer og restrukturerer “grafen” på oversettelsene i disse filene parallellt med at vi rydder opp i koden og ser bruken av dem
    

1.  Når de lokale oversettelsesfilene er stabile nok i forhold til struktur, så importeres de til Strapi som grunnalg for redaktørstyrt oversettelse der.
    

# Fremdriftsplan

*   [Flemming Hansen (Unlicensed)](https://bufdir.atlassian.net/wiki/people/60feb0dc627b5600689a9003?ref=confluence) Kopiere DSM tekster fra ajax results og inn i vesjonerte json-filer
*   [Jan Sondre Sikveland (Unlicensed)](https://bufdir.atlassian.net/wiki/people/6163f84964ff010071aac7b8?ref=confluence) Sette opp MVP (“Demotest”) instans for Strapi med mulighet for redaktører å logge inn
*   [Flemming Hansen (Unlicensed)](https://bufdir.atlassian.net/wiki/people/60feb0dc627b5600689a9003?ref=confluence) PoC på henting og bruk av oversettelser fra Strapi (1 dag)
*   [Kuda Chambwe (Unlicensed)](https://bufdir.atlassian.net/wiki/people/5f8d583006c34300698a9d8e?ref=confluence)[Flemming Hansen (Unlicensed)](https://bufdir.atlassian.net/wiki/people/60feb0dc627b5600689a9003?ref=confluence) Restrukturere / normalisere oversettelser i json filene (Unknown time)
*   [Flemming Hansen (Unlicensed)](https://bufdir.atlassian.net/wiki/people/60feb0dc627b5600689a9003?ref=confluence) sende de “normaliserte” json-filene til Jan Sondre
*   [Jan Sondre Sikveland (Unlicensed)](https://bufdir.atlassian.net/wiki/people/6163f84964ff010071aac7b8?ref=confluence) Importere oversettelser fra json-filer inn i Strapi (1 dag)

## Resource Namespaces

| **Namespace** | **Domene** | **Lokasjon** |     |
| --- | --- | --- | --- |
| System | System | Fil | Kun tekster for feilmeldinger som kan intreffe før Innholds-domener er lastet |
| DSM | Innhold | API | Tekster for landingssiden. Kan ha en viss overlapp med både `System` og `FSA` namespaces |
| FSA | Innhold | API | Tekster for `AgreementForm` og `ArgeementSummary` |
|     |     |     |     |

# Azure “Demotest” instans

nå kjører den på http://fsa-content-devtest.norwayeast.azurecontainer.io:1337/

så du autentiserer deg på http://fsa-content-devtest.norwayeast.azurecontainer.io:1337/api/auth/local med json body:

```
{
  "identifier":"admin",
  "password":"Admin12345!"
}
```

og bruker jwt som bearer token til å kalle på APIet, f. eks. http://fsa-content-devtest.norwayeast.azurecontainer.io:1337/api/dsm-language?populate=\*

du trenger ?populate=\* per nå fordi language content typene ikke har custom controllers

de to andre tilgjengelige språktypene er /api/error og /api/myagreements-translation

for error kan du også legge til &locale=nb-NO eller &locale=en for norsk og engelsk

http://fsa-content-devtest.norwayeast.azurecontainer.io:1337/api/error?populate=\*&locale=en