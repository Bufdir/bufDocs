# FSA - Feilsøking

# Logging

## Backend

FSA Backend benytter seg av SeriLog for logging. Loggingen er satt opp til å logge mot cosmos-db og i tillegg ut til Azure App Service - Diagnostic stream.

### Azure app service log stream

For å se loggene i Diagnostic stream på azure app service må logging til filsystem aktiveres under menypunktet “App service logs”

![](./attachments/image-20220908-063359.png)

**Azure Application Insights**

Det logges per 08.09.2022 til Azure Application Insights på test - dette vil på sikt erstatte cosmos-db som en loggdestinasjon.

### Azure Cosmos DB

En del informasjon fra azure function som er ansvarlig for opprydding i database blir også logget til Azure Cosmos DB - også via Serilog, disse kan finnes Cosmos DB som er tilknyttet den kjørende FSA-instansen. Connection strings ligger i Key Vault og data kan kikkes på gjennom Query Explorer-blade under cosmos db instansen.

et eksempel på spørring som kan benyttes er

`SELECT c.Level, c.Message, c.Timestamp FROM c`  
`order by c._ts desc`