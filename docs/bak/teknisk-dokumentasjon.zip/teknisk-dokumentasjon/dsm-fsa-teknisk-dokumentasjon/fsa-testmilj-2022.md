# FSA - Testmiljø 2022

Subscription: Utvikling

Resource group: rg-DSM

[fsa-app-dev](https://portal.azure.com/#@fantomet.onmicrosoft.com/resource/subscriptions/545c75ca-6637-42cf-9e01-d1e9b65fe4d6/resourceGroups/rg-DSM/providers/Microsoft.Web/sites/fsa-app-dev) - webapplikasjon

fsa-func-dev - Kjører funksjon som rydder opp i gamle avtaler som ikke er signert o.l. - logger mot cosmos

**PG: Slettet 05.05.2023 - ikke i bruk lenger**

[dsm-fsa-keyvault-dev](https://portal.azure.com/#@fantomet.onmicrosoft.com/resource/subscriptions/545c75ca-6637-42cf-9e01-d1e9b65fe4d6/resourceGroups/rg-DSM/providers/Microsoft.KeyVault/vaults/dsm-fsa-keyvault-dev) - Key vault som lagrer konfigurasjon

[dsm-fsa-sqlserver-dev](https://portal.azure.com/#@fantomet.onmicrosoft.com/resource/subscriptions/545c75ca-6637-42cf-9e01-d1e9b65fe4d6/resourceGroups/rg-DSM/providers/Microsoft.Sql/servers/dsm-fsa-sqlserver-dev) - databaseserver

[fsa-cosmosdb-dev](https://portal.azure.com/#@fantomet.onmicrosoft.com/resource/subscriptions/545c75ca-6637-42cf-9e01-d1e9b65fe4d6/resourceGroups/rg-DSM/providers/Microsoft.DocumentDB/databaseAccounts/fsa-cosmosdb-dev) - cosmos db

**PG: Slettet 05.05.2023 - ikke i bruk lenger**

[fsa-db-dev (dsm-fsa-sqlserver-dev/fsa-db-dev)](https://portal.azure.com/#@fantomet.onmicrosoft.com/resource/subscriptions/545c75ca-6637-42cf-9e01-d1e9b65fe4d6/resourceGroups/rg-DSM/providers/Microsoft.Sql/servers/dsm-fsa-sqlserver-dev/databases/fsa-db-dev) - SQL database