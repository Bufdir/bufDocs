# FSA flow - Prosess og flyt

Her er diverse prosess flyt, først fra teknisk dokumentasjon for første løsning og med kartlagt prosess (BMPN format) etter første fase med re-design. Merk at siste BPMN diagramet ikke har med prosessen for signering av avtalen, etter det er fortsatt under utvikling. Den siste tar i utgangspunkt i hele flyten fra oppretelse av avtale til deling av avtalen.

## Oversikt

### Initiell process flyt LEGACY

![](./attachments/Screenshot%202022-05-10%20at%2012.12.39.png)

### Ønsket prosess flyt LEGACY

![](./attachments/image-20220510-155328.png)

### Kartlagt flyt etter re-design (uten prosess for signering) IMPLMENTERT

![](./attachments/fsa-bpmn.png)

## Signeringsflyt

*   [https://signering-docs.readthedocs.io/en/latest/signeringsflyt.html](https://signering-docs.readthedocs.io/en/latest/signeringsflyt.html)
    
    *   [https://signering-docs.readthedocs.io/en/latest/client-integration/direct-flow.html#step-3-get-status](https://signering-docs.readthedocs.io/en/latest/client-integration/direct-flow.html#step-3-get-status)
        

### Slides fra posten.no