# Status etter Sprint 50 (11.05.2022)

I Sprint 50 ble det allokert en frontendutvikler for å få til en [happy-path](https://en.wikipedia.org/wiki/Happy_path) for fra login til ferdig signert avtale.

Før Sprint 50 var det gjort arbeid for å kunne implementere design for Reskinn Epice’en, og det medførte behov for ende-til-ende-testing av avtale-prosessen.

Etter planen skulle det først lages en mer detaljert dokumentasjon på ende-til-ende-flyten som dokumenterer API kall og React componenter relatert til stegene i prosessen. Dette ble ikke oppnådd.

Problemet er sammensatt av flere ting, og flere av disse ble ryddet opp i etterhvert som det ble avdekket / identifisert i kodebasen:

## Problemer

### Tilgang til DigiPost

Manglende innlogging for test-brukere på DigiPost for å kunne fullføre signeringsprosessen.

Vi regnet med at de opprinnelige utviklerene hadde tilgang til alt de trengte for å teste, men det ble sent i Sprint 50 avklart at siste del av prosessen, Digital Signering via DigiPost, ble testet av et par ansatte som tilfeldigvis hadde livsituasjon som gjorde at de kunne teste.

Det ble satt igang korrespondanse for å få opprettet riktige testbrukere på DigiPost, men det er fortsatt ikke avklart hvor vi skal henvende oss for dette.

Pdd. har vi ikke tilgang til Digipost for testbrukerene våre.

### Kodekvalitet

Uforutsett mange lag med logikk som måtte konsolideres for å få oversikt over flyten:

1.  State: Hoisting og prop-drilling
    
2.  Routing: `window.location=xxx?a=b`
    
3.  API format og Feilhåndtering: Duplisert kode per fetch blandet med hånderting av response data
    
4.  Form handling: `<Formik>` med workarounds / ikke `<Formik>`
    

Alle disse punktene var koblet sammen, i tillegg til:

*   forvirrende navngivning av variabler
    
*   overkompliserte datastrukturer
    
*   duplisering av variabelnavn i inner-scopes
    
*   feil bruk av Javascript metoder (array.map med side-effekter, med og uten bruk av return-verdi)
    
*   Duplisering av kode fremfor enkapsulering i - og gjenbruk av - funksjoner
    

## Status

### Endringer

*   API-respons fra backend er endret til veldig enkel bruk av JSON Api - standarden
    
*   XHR-Feilhåndtering er en del av `React`\-flow ved bruk av hook `useApi()`
    
    *   All “non-happy-path” bloat er fjernet ukritisk.
        
*   React Router er oppgradert til v6 og har fått fullt ansvar for routingen etter autentisering (innlogging) og autorisering (samtykke)
    
*   Autentisering og Autorisering wrapper Routeren
    
    *   Autentisering “window.redirecter” ut av SPA’en til [dotnet backend for innlogging](#login-redirect)
        
    *   Autorisering krever samtykke før SPA routeren får kontroll
        
*   State bruker flux pattern (tenk redux) basert på `React.useReducer` og `React.Context`. Aksesseres med hook `useAppState()`
    
*   `AgreementSummary` page er fjernet til fordel for “Print” handling fra `AgreementCard`
    
    *   Kan reinstitueres senere når grensensittet er definert ved bruk fra `AgreementCard`, enn så lenge så er det bloat å to innganger, hvorav den antar “legacy routing”
        

#### Known issues (Frontend + Backend)

*   Login redirect må forsikre at backend loginService redirecter til opprinnelig url. Dette gjelder spesielt for login før `/?asr=xxxx` sharing-request url'er
    
    *   Brukermelding om aksept mangler
        
*   AgreementForm::saveForm bug med feil/manglende data til BE
    
    *   Bedre tilbakemelding på feil i forhold til modellen?
        
*   Signeringsprosessen - Happypath
    
    *   Testbrukere for innlogging til DigiPost
        
    *   Whiteliste enkelte epostdomener adresser for testing
        
    *   Forsikre at stegen i signeringprosessen er riktig
        
        *   Lage en statemachine til bruk frontend for å dokumentere stegene konsist i koden
            

### Gjenstående

Se også [FSA - Tekniske avklaringer](../../dsm-fsa-teknisk-dokumentasjon/fsa-tekniske-avklaringer.md)

*   Oversettelser: i18next translations fra ny Strapi instans
    
*   \`AgreementCard\` på Landingssiden:
    
    *   Status og tilgjenglige handlinger fra gitt status, e.g “Rediger”, “Slett”, “Del” osv.
        
    *   Tilbakeføre “alle” brukermeldinger / ekstra informasjon rundt stegene i prosessen
        
        *   Dette er en task som involverer design, men designerene må først få en gjennomgang av prosessen
            
*   `AgreementForm`: tøm feltene funksjonalitet
    
    *   “Start på nytt”?
        
*   Footer: Bruker innhold fra API `BufdirFramework`
    
    *   Hvor tidlig skal dette på plass? - Krever det login?