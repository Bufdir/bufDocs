# Lisens oversikt

Oversikt over lisenser på propriotær programvare som er benyttet i forbindelse med [http://bufdir.no](http://bufdir.no) prosjektet eller sideprosjekter.

| **Produkt** | **Kontakt/Ansvarlig** | **Utløp (automatisk fornyelse j/n)** | **Brukes hvor** |
| --- | --- | --- | --- |
| EpiServer (Optimizely) - qa/prod | Håvard | 28.09.2023 (n) | QA og prodmiljø |
| Episerver (Optimizely) - Dev (test) | Håvard | 20.10.2023 (n) | Testmiljø |
| iText7 | Richard Næss | 30.12.2022 (n) | DSM(FSA), PDF generering |
| ImageResizer | Epinova (nr 639078372) | ?   | [Bufdir.no](http://Bufdir.no), [http://bufdir.no](http://bufdir.no) reboot |
| Hotjar<br><br>[Hotjar: Website Heatmaps & Behavior Analytics Tools](https://www.hotjar.com/) | Daniel Walø | april 2024 | Brukerundersøkelser, innsiktsarbeid, webanalyse |
| Matomo | Daniel Walø | ?   | Webanalyse (erstattet GA juli 2023) |
| Swifttype | Håvard | Neste mnd (ingen bindningstid) | Som crawler og søk-løsning på gamle [bufdir.no](http://bufdir.no) sider |
| MediaFlow<br><br>[https://www.mediaflow.com/](https://www.mediaflow.com/) | Karoline Kvellestad Isaksen [karolinekvellestad.isaksen@bufdir.no](mailto:karolinekvellestad.isaksen@bufdir.no) | ?   | Video-plattform. (erstattet GA i høst 2023) |