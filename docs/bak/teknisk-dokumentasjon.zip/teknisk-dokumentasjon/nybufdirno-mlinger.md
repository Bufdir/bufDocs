# ny.bufdir.no - Målinger

**Notis pr. 02.05.22**

Målinger er i vinden i skrivende stund (02.05.22), pga Schrems 2, og det som er dokumentert her kan med relativ sannsynlighet måtte komme til å endres til å se ganske annerledes ut når konklusjon om målingers fremtid er klar.

**Notis pr. 10.08.22**

Målinger per dags dato har blitt implementert til å støtte forespørsel fra Terje, dypere beskrevet i vedleggene. Ønsket er event-tracking ved bruk av data attributer slik at man kan kun tracke spesifikke klikk.

[Bufdir-forside\_link-kate…](/wiki/spaces/BUF/pages/2408218625?preview=%2F2408218625%2F2507735041%2FBufdir-forside_link-kategorier_juni+2022.pptx)[Målinger - Detaljer om l…](/wiki/spaces/BUF/pages/2408218625?preview=%2F2408218625%2F2507702273%2FM%C3%A5linger+-+Detaljer+om+lenketype.docx)

## Google Tag Manager og kode

Grensesnittet mellom koden i webløsningen og analyse av målinger er Google Tag Manager.

Vi har et generelt globalt script, som tillater GTM/GA å gjøre en del generiske målinger, som f.eks antall sidetreff pr url, samt å oppette spesialiserte målinger.

```
<!-- \_GoogleTagManager.cshtml -->
<!-- Google Tag Manager -->
<script>
(function(w,d,s,l,i){w\[l\]=w\[l\]||\[\];w\[l\].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)\[0\],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','@Model.SiteSettings.GoogleTagManagerContainerId');</script>
<!-- End Google Tag Manager -->
```

Disse spesialiserte målingene kan enten gjøres ved å trykke seg rundt i GTM sitt brukergrensesnitt frakoblet fra koden og gjøre målinger mot kodens synlige elementer (html) i nettleseren, eller ved at koden selv kjører eventer på elementer direkte til GTM.

Å kjøre målinger fra GTM sitt grensesnitt er frakoblet fra fra koden og dens utviklere og vil derfor være sårbar for endringer i koden. Den er avhengig av at den synlige koden i nettleseren (html) ikke endres, fordi endringer i denne koden vil kunne gjøre slik at målingene definert ikke finnes elementene den var satt opp til å finne.

Ved å sende målinger fra koden, sikret vi at målingene ikke er direkte avhengig av at html består uberørt, men heller er en integrert del av utviklingsprosessen. Når kode endres (noe den gjør kontinuerlig), så vil målingene synes for utviklerne, som da har et bedre utgangspunkt for å viderføre disse.

### Plan for spesialiserte målinger

Lover for innsamling av data påpeker at for å samle inn persondata, så må man ha en uttalt grunn for å samle det inn. Historisk har man målt så mye som mulig slik at man kan grave ut det man vil rapportere på i etterkant, mens nå ønsker vi å ha en plan med målingene vi gjør, i tillegg til å holde det til et minimum. Vi ønkser å måle kun det vi har behov for.

Praktisk vil dette gjennomføres ved at, for hvert område vi bygger om i ny løsning ([http://ny.bufdir.no](http://ny.bufdir.no) ), så får vi en bestilling fra analyse med de spesialiserte målingene man ønsker å ha, samt et behov og mål med disse målingene. Disse målingene og behovene må dokumenteres av analyse.

### Spesialiserte målinger i kode

Vi har to forskjellige typer målinger - standardmålinger og e-commercemålinger. Koden for disse ser slik ut:

#### Standardmåling

```
// gtm.ts

/\*\*
 \* This function sends info about the page area and a user action performed to Google Tag Manager.
 \* Assumes GTM is initialized globally in the backend. Does nothing if it isn't.
 \*
 \* @param {object} event - container object
 \* @param {string} event.category - What area of the site the user is on, i.e 'Foreldrestil-test'
 \* @param {string} event.action - Name of action the user is performing, i.e 'Resultat - foreldretype'
 \* @param {string} event.label - The value of the action performed by the user, i.e 'Prosjektlederen'
 \*/
const passStandardEventToGTM = (event) => {
  window.dataLayer = window.dataLayer || \[\];
  window.dataLayer.push({
    event: 'ga\_event',
    ec: event.category,
    ea: event.action,
    el: event.label,
  });
};
```

#### E-commercemålinger

```
// gtm.ts

function getFriendlyNamedEventFormat(eventFormat: number) {
  switch (eventFormat) {
    case 1:
    case 2:
      return 'Fysisk';
    case 3:
      return 'Digitalt';
    default:
      return '';
  }
}

const passECommerceEventToGTM = ({
  region,
  eventCategory,
  eventName,
  timeId,
  eventFormat,
}) => {
  window.dataLayer = window.dataLayer || \[\];

  const translatedeventFormat = getFriendlyNamedEventFormat(eventFormat);

  const data = {
    event: 'kursTransaksjon',
    transactionId: uuidv4(),
    transactionAffiliation: region,
    transactionTotal: 0,
    transactionProducts: \[
      {
        sku: \`${region} - ${eventName} - ${timeId}\`,
        name: \`${region} - ${eventName} - ${timeId}\`,
        category: \`${region};${eventCategory};${translatedeventFormat}\`,
        price: 0,
        quantity: 1,
      },
    \],
  };

  window.dataLayer.push(data);
};
```

Pr dags dato har vi 4 spesialisterte målinger:

*   global (fant du det du lette etter)
    
*   2 for fosterhjem (påmelding og kontakt)
    
*   1 for familievern (påmelding).
    

#### Globale målinger

I skrivende stund, har vi en global spesialisert måling som sender til GTM for hver gang en bruker trykker ja eller nei på “Fant du det du lette etter”. Målingen forteller at det er “Fant du det du lette etter”-komponenten som rapporteres fra, hvilken tjeneste (“siteRegion” i koden - verdi er f.eks “fosterhjem”, eller “Familievern”) som som brukeren er på og om brukeren trykket “ja” eller “nei”.

Vi sender ikke med teksten som brukeren skriver inn i tekstboksen til GTM/GA.

```
passStandardEventToGTM({
  category: siteRegion,
  action: 'Fant du det du lette etter',
  label: isPositive ? 'Ja' : 'Nei',
});
```

#### Kurspåmelding/kontaktskjema fostehjem og familievern

For kontaktskjema sender vi en standard måling med informasjon om tjenesten bruker er på, at det er kontaktskjema og headeren til kontaktskjemaet. Vi sender ikke med informasjon som brukeren har fylt inn i skjemaet.

For påmeldingsskjema sender vi en e-commersemåling med informasjon om region, tjeneste, navnet på møte/kurs og eventformat (fysisk eller digitalt).

```
export const passEventToGtm = (
  requestType: number,
  eventGuid?: string,
  region?: string,
  eventName?: string,
  timeId?: string,
  contactFormHeader?: string,
  eventFormat?: string,
  isRecipientROS = false,
) => {
  const siteRegion = isRecipientROS ? 'Fosterhjem' : 'Familievern';

  if (!isRecipientROS || (isRecipientROS && requestType === 5)) {
    // ROS requestType == 5 - EventBooking
    passECommerceEventToGTM({
      eventGuid,
      region,
      eventCategory: \`${siteRegion} - kurspåmelding\`,
      eventName,
      timeId,
      eventFormat,
    });
  }

  if (isRecipientROS && requestType === 4) {
    // ROS requestType == 4 - ContactMe
    passStandardEventToGTM({
      category: \`${siteRegion} - sendt henvendelse – bekreftelse\`,
      action: 'Kontaktskjema',
      label: contactFormHeader,
    });
  }
};
```

##### Tilleggsinformasjon til koden

I skrivende stund har vi en komponent i frontend, ContactForm, som brukes til påmeldingsskjema til kurs/møter på fosterhjem og familievern, og til kontaktskjemaet på forsterhjem.

Hvis skjemaet som sendes skal til ROS (fagsystem som utvikles av avdelingen “Løsningsutvikling”), så vet vi at det er fosterhjemsområdet, og da sjekker vi om skjemaet er et kontaktskjema eller et påmeldingsskjema ved å se på hvilken ROS-type som er definert. ROS definerer kontaktskjema som type 4 og påmeldingsskjema som type 5.

Hvis skjemaet ikke skal til ROS, så vet vi at det er snakk om familievern, og at det da er et påmeldingsskjema.

## Dataattributter som målepunkter for sporing via eksterne systemer

Merk at det er ikke optimalt å lage tracking-events fra eksterne systemer, men denne metoden med data attributer er for tilfeller hvor vi ikke har mulighet til å sende eventer. Dette er en foretrukket måte for å spore enkeltelementer enn via CSS-klasser og ID’er som kan fort endre seg uavhengig av måling.

Data attributer og i dette tilfelle som er custom (i.e. `data-*`), er attributer bestående av nøkkel og verdi. De brukes til mye forskjellige ved å legge til data i HTML markup. I dette tilfelle for å kunne tracke klikk-elementer med spesifikke attributer.

Denne metoden slik den er implementert tillater kun utviklere å legge til eller sette attributer. Man kan tillate en annen måte å endre dette fra redaktør sin side, men dette må implementeres.

Eksempel på html lenke-element med en custom data attributt:

```
  <a href="/" className="bl-link" data-tracking-id="transportlinkanchor">
    <span>Link tekst her</span>
  </a>
```

For slike tilfeller skriver man HTML selv, så man har mulighet til å fritt legge til data attributer (ref. kode-eksempel over). Data attributtet i dette tilfelle er da `data-tracking-id="transportlinkanchor"`.

**Buflib støtte i.e. React komponenter:**

For React komponent hvor konsumenten ikke har direkte tilgang til HTML markupen, er dette lagt støtte for i form av “props”. Dagens implementasjon er for lenke-elementer så komponentene som inneholder lenke-elementer har primært en prop `dataAttributes` for å sette vilkårlig antall attributer.

Eneste unntaket hvis komponenten har lenke-element og/eller lenke-liste-elementer (i.e. TeaserLink) så har setter man attributer for lenke i lista på propen `linkListDataAttributes`. Mer spesifikke detaljer og eksempler finner i [buflib\_docs](https://stbuflibdev.z16.web.core.windows.net/?path=/docs/introduction-welcome--page). Dette gjelder foreløpig react komponenter Footer og TeaserLink.

Eksempel fra buflib med data attribut(er) sendt som props:

```
<BlTeaserLink url="#" 
  image={{
    url: 'https://picsum.photos/500/400',
    ariaText: 'Illustration',
  }} 
  linkText="Text for link here" 
  dataAttributes={{
    'data-my-extra-prop': 'mypropvalue',
    'data-my-second-extra-prop': 'mysecondpropvalue'
  }} 
/>
```