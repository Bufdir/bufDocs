# Repository strategi

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

\# Behov

[Bufdir.no](http://Bufdir.no) utvikler teamet har mange prosjekter / Applikasjoner som de forvalter og videreutvikler. Noen av disse er knyttede løsninger inn i hovedløsningene ([bufdir.no](http://bufdir.no)), mens andre er standalone som er koblet på fra utsiden. I tillegg har vi et par helt frakoblede tjenester (feks noeharskjedd) og fellestjenester (bufNotificationsAPi, PostnrRegister) som vi arbeider på.

Disse skillene er pr dags dato dårlig organisert både organisatorisk (I form av dokumentasjon, strategi og plan, oppgaver osv) og teknisk (I form av infrastruktur og kode struktur).

Pr i dag har [bufdir.no](http://bufdir.no) teknisk team laget et repository pr "prosjekt", som vil si at vi har i overkant av 20 repository (repo\*) i vårt repo verktøy Azure Devops.

Det er ønskelig å få ned dette til et mer håndterbart nivå, da hver av disse krever egen deployment og egen forvaltning av policy, regler, oppdateringer osv.

Teknisk team ser behov for å lage et mer markert skille på de tekniske løsningene, samtidig som vi samler elementer som naturlig hører hjemme sammen. Dette gjør vi gjennom et domene basert oppsett, hvor hvert domene samles i et mono-repo.

Fra "Domain driven design" boka:

```
\`\`\`quote
```

```
title: Definition of Domain
```

```
The definition of a DDD domain by Andrew Powell-Morse is:
```

```
\> Domain in the realm of software engineering commonly refers to the subject area on which the application is intended to apply. In other words, during application development, the domain is the "sphere of knowledge and activity around which the application logic revolves.
```

```
\`\`\`
```

I denne context vil et domene typisk være en samling av tekniske løsninger som bygger opp under samme løsning, eksempelvis Digitalt Støttet Mekling som er bygget opp av følgende repository:

FSA\_Content

FSA

DsmApi

Dette blir samlet til et mono-repo, med 3 prosjekter / collections under, som typisk ville blitt kalt DSM.

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

\## Effekt

Effekten vi ønsker å oppnå med denne endringen er bedre skiller på hvor endringer hører hjemme, gjennom å kjøre et hardt skille på de ulike domenene.

Bedre deployment da hvert domene vil naturlig måtte deployes som en enhet, siden de har interne avhengigheter.

Bedre forståelse for hvor endringene hører hjemme, gjennom en tydeligere definisjon av domenene våre.

Bistå funksjonene rundt oss med forståelse av løsningene, gjennom å definere skillene og domene på en mer forståelig måte for organisasjonen

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

\## Verktøy

I forbindelse med dette vil vi migrere kodebasen fra Azure Devops til Github. Dette for å ta nytte av de bedre integrasjonene og oppdaterte verktøyene som ligger klare for oss der. Github vil også gi oss muligheten til å nytte oss av nye infrastruktur alternativer, da mange ting kun støtter deployment fra github i azure portalen.

Dette vil ha minimalt med påvirkning for organisasjonen ellers, men vil gjøre både hverdagen og onboarding av nye tekniske ressurser lettere, da github er et mye mer utbredt verktøy for å håndtere repoer enn det azure devops er, og fungerer like bra i sammarbeid med devops sin oppgavehåndtering som devops eget lagrings alternativ.

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

\## Omfang

Selve omfanget av skiftet blir forholdsvis lite, da det finnes ferdige verktøy for dette i github.

Det vil kreve en formalisering av bruken av verktøyet fra systemeier sin side, støttet med informasjon i dette dokumentet.

Det vil kreve at vi gjør om litt på repo i devops og kobler disse fra github istedenfor devops, ca 30 min pr repo (i github, som vil være færre).

Det vil kreve noe tid i form av rydding i repoer (som vi må gjennom uansett hva vi hadde valgt), i form av å organisere disse som mono-repoer med nye policys og deployment pipelines (ca 1-3 dager pr domene).

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

\## Domener

Vi har identifisert følgende domener:

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

DSM (før FSA)

`-` dsm-iac (Avventes, kandidat til eget repo?)

`-` DSM.E2ETests

`-` FSA

`-` FSA\_Content

`-` FSA.AgreementCleanup

`-` DsmApi

`-` Bufdir.Notifications.Api

`-` Bufdir.Abstractions.Notifications

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

BufdirNo (før \[[http://ny.bufdir.no](http://ny.bufdir.no) \]([http://ny.bufdir.no/](http://ny.bufdir.no/) )

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

)

`-` [Terraform-Ny.Bufdir.No](http://Terraform-Ny.Bufdir.No) (Avventes, kandidat til eget repo?)

`-` \[[Bufdir.no](http://Bufdir.no)\]([http://bufdir.no/](http://bufdir.no/))

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

`-` Bufdir.familievernapi

`-` Bufdir.Fosterhjem.Api

`-` Bufdir.FeedbackApi

`-` Bufdir.Newsletter.Api

`-` BufDirNoCli

`-` BufRedirect

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

BufdirNoLegacy <før \[[bufdir.no](http://bufdir.no)\]([http://bufdir.no/](http://bufdir.no/))

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

\>

`-` \[[Bufdir.no](http://Bufdir.no)\]([http://bufdir.no/](http://bufdir.no/))

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

Statistics (nytt repo)

`-` Stat\_content

`-` Stat\_backend

`-` Stat\_frontend

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

NoeHarSkjedd (før noeharskjedd)

`-` \[[http://noeharskjedd.no](http://noeharskjedd.no) \]([http://noeharskjedd.no/](http://noeharskjedd.no/) )

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

Fellestjenester

`-` Postal.Api

`-` Api.Library

​

![](https://bufdir.atlassian.net/wiki/plugins/servlet/confluence/placeholder/error?i18nKey=editor.placeholder.broken.image&locale=en_US&version=2)

Buflib

`-` Buflib

`-` Buflib\_Cli

`-` buflib\_docs

`-` buflib\_example

Archive