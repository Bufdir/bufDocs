# Valg av metarammeverk

## Hvorfor

Vi har lenge levd med en gammeldags custom hybridløsning for å kunne rendre frontend-komponenter, laget i React, i [http://bufdir.no](http://bufdir.no) .

Denne løsningen ble deprecated, og i løpet av de siste årene har nye praksisser for bygging av frontend på en mer smidig, stabil og ytelsesdyktig måte kommet til, ved bruk av det som kalles meta-rammeverk.

Vi bruker React som frontendrammeverk, så vi vurderte ikke meta-rammeverk som er bygget for andre frontend-rammeverk, som Nuxt (Vue.js), SvelteKit (Svelte) osv.

## Hvilke vi vurderte

### Next.js

#### Beskrivelse

En React-basert rammeverk for å bygge nettsider og applikasjoner. Det muliggjør server-side rendering (SSR), statisk generering og klient-side navigasjon.

114,000 stjerner på Github  
3,739,315 ukentlige nedlastinger på npmjs

#### Første vurdering

Pros: Støtter alt vi trenger. Positivt førsteinntrykk. Flere fra React-teamet jobber med det. Backa av Vercel. Stort community, mye brukt.  
Cons: Knytning til annen cloud provider enn Azure, som vi bruker

### Astro

#### Beskrivelse

En moderne rammeverk som fokuserer på ytelse ved å bygge raske og lette nettsteder ved å bruke modulære byggeblokker og statisk generering der det er hensiktsmessig.

Har egen syntax for statisk innhold og støtte for flere frontend-rammeverk (React/Svelte/Vue osv)

36,800 stjerner på Github  
138,115 ukentlige nedlastinger på npmjs

#### Første vurdering

Pros: Støtte for flere rammeverk (mulig å bytte ved behov i fremtiden).  
Cons: Førsteparts funksjoner ikke tilgjengelig i React. Flere metodikker å forholde seg til.

### Remix

#### Beskrivelse

Et rammeverk som fokuserer på ytelse og skalerbarhet ved å tilby avanserte teknikker for server-side rendering (SSR), prefetching av data og klientside-navigasjon.

25,000 stjerner på Github  
12,764 ukentlige nedlastinger på npmjs

#### Første vurdering

Pro: Støtter alt vi trenger  
Con: Nytt, ikke "battle-testa". Ikke så mange brukere.

### Gatsby

#### Beskrivelse

En statisk sidegenerator bygget med React. Gatsby fokuserer på å skape raske, sikre og SEO-vennlige nettsteder ved å bruke moderne webteknologier som GraphQL for datahåndtering.

54,800 stjerner på Github  
246,525 ukentlige nedlastinger på npmjs

#### Første vurdering

Pros: Rask, god SEO  
Cons: Ikke mye i bruk lenger. Ingen støtte for oppdateringer runtime.

## POC

### Innledning

Etter innledende vurderingsfase bestemte vi oss for å droppe Gatsby, fordi det er dalende i popularitet og er bygget opp på gamle konvensjoner, og Remix fordi det er stort sett det samme som Next.js minus backing fra React-teamet og Vercel og med en mindre brukerbase.

Vi laget 2 POCer, en for Next.js og en for Astro for å få et godt vurderingsgrunnlag på begge.

### Hva vi bygget

*   3 sidemaler
    
*   routing
    
*   integrasjon mot Optimizely sitt "Content Delivery API"
    
*   bildeoptimalisering
    
*   mapping fra Optimizely blokker til React-komponenter
    

### Resultat

Vi fikk utført jobben vi skulle i begge meta-rammeverkene vi testa. Meta-rammeverkene har veldig lignende praksis for alle underjobbene som ble implementert, men Astro hadde litt dårligere ergonomi fordi man må ha to forskjellige metodikker/rammeverk for statisk innhold kontra interaktivt innhold. Statisk innhold lager man i Astro sin egen syntax, mens dynamisk innhold krever et frontendrammeverk - React i dette tilfelle.

I Astro blir det blir et skarpt skille mellom å jobbe i Astro-delen og i React-delen, som skaper mindre produktivitet.

Next.js har også flere ganger så stor brukermasse og ukentlige nedlastinger, har lenger fartstid, og er støttet av React-utviklere direkte.

Disse faktorene gjør at vi velger å gå videre med Next.js