# Retningslinjer for Azure miljø, konfigurasjon og Secrets

**Azure:**

I tillegg til produksjonsmiljøet kan det være tre ulike miljøer i Azure:        

*   Utvikling (Development): Dette miljøet vil inneholde felles ressurser som kan brukes under utvikling på den lokale maskinen.
    
*   Test: Dette miljøet vil kontinuerlig motta oppdateringer fra utviklingen (deployments fra develop-branchen). Miljøet er også ment for testing før deployment til QA-miljøet.
    
*   QA: Dette miljøet er et testmiljø før deployment til produksjon.
    

Merk: Tidligere ble det utført deployments fra develop-branchen til Development-miljøet, og Test var et dedikert testmiljø. På grunn av at overheaden med å ha to miljøer var større enn fordelen, ble det besluttet at develop-branchen skal deployes til Test-miljøet på Fantomet.

**Konfigurasjon:**

I hvert miljø bør environment-variabelen gjenspeile navnet på miljøet, enten "development", "test", "qa" eller "production". Environment-variablene settes i Application Settings i Azure.

Konfigurasjonen bør hovedsakelig ligge i appsettings.json-filene, der hvert miljø har sin spesifikke fil. Filene bør navngis etter det tiltenkte Azure-miljøet:

*   appsettings.development.json: Development-miljøet. Her ligger konfigurasjonen for de felles ressursene som benyttes i Fantomet.
    
*   appsettings.test.json: Test-miljøet.
    
*   appsettings.qa.json: QA-miljøet.
    
*   appsettings.production.json: Produksjonsmiljøet.
    
*   appsettings.local.json: For personlige ressurser på den lokale maskinen. Denne filen bør ikke inkluderes i kildekontrollen.
    

 **Secrets:**

Alle hemmeligheter bør lagres i Azure Key Vault og skal ikke være en del av appsettings.json-filene eller Application Settings i Azure. For lokal utvikling kan secrets.json benyttes.