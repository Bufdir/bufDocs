# DSM / FSA teknisk dokumentasjon

Her er alt av teknisk dokumentasjon for alt DSM (Digital Støttet Mekling) relatert. Merk at dette er mest for utvikling og alt av krav, målplan dekkes ikke på denne siden. For litt mer informasjon rundt dette, les [DSM Digital timebestilling MVP](https://bufdir.atlassian.net/wiki/spaces/BUF/pages/2292809729).

## Foreldresamarbeidsavtalen (FSA) UNDER UTVIKLING

Arbeidet som har gjort så langt; Vi har tatt i utgangspunktet i koden som eksisterte, for å så byttet ut gammelt design med nytt, bytte ut gammelt komponentbibliotek med nytt og lage noen nye features (f.eks print av avtale fra “min side”), og vi har “mocket” litt av det som skal komme relatert til “begjær mekling”.

En del kode, biblioteker osv var utdatert og er forsøkt byttet ut og fjernet hvis det ikke har noe ønsket funksjon. Implementasjonen har tatt utgangspunkt i følgende skisser: [https://zpl.io/bzp7gKA](https://zpl.io/bzp7gKA)

![Skjermbilde av gammel forside](./attachments/image%2092.png)

## Begjær Mekling (BM) IKKE PÅBEGYNT

Avventer bekreftelse om videre arbeid. Pr. nå ikke prioritert.

Skisser [https://zpl.io/VkL6Z5G](https://zpl.io/VkL6Z5G)